package com.prdc.service;

import java.util.List;

import com.prdc.bean.CompanyInfoBean;
/**
 * @author Tilak R
 
 * 
 */
public interface CompanyInfoService {
	
	
	String saveCompanyInfo(CompanyInfoBean companyInfoBean);

	List<CompanyInfoBean> getCompanyInfoList();

	List<CompanyInfoBean> getCompanyInfoDetails(String id);

	String updateCompanyInfoDetails(CompanyInfoBean companyInfoBean);

	List<CompanyInfoBean> getSellerCompany();

	List<CompanyInfoBean> getBuyerCompany();

	List<CompanyInfoBean> getTraderCompany();

}
