package com.prdc.service;

import java.util.List;

import com.prdc.bean.CompanyInfoBean;
import com.prdc.bean.ContractBean;
/**
 * @author Tilak R
 
 * 
 */
public interface ContractService {

	String insertContract(ContractBean cb);
	
	List<ContractBean> getContractList();
	
	List<ContractBean> getContractInfoDetails(String id);

	String updateContract(ContractBean cb);

}
