package com.prdc.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prdc.bean.CompanyInfoBean;
import com.prdc.dao.MainDao;
import com.prdc.service.MainService;
/**
 * @author Tilak R
 
 * 
 */
@Service
public class MainServiceImpl implements MainService{
	
	@Autowired
	private MainDao mainDao;

	public List<String> getValues() {
		// TODO Auto-generated method stub
		return mainDao.getValues();
	}

}
