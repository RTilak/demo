package com.prdc.service;

import java.util.List;

import com.prdc.bean.CompanyInfoBean;
/**
 * @author Tilak R
 
 * 
 */
public interface MainService {

	List<String> getValues();

	
}
