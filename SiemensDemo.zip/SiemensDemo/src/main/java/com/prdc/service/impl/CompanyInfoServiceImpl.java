package com.prdc.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prdc.bean.CompanyInfoBean;
import com.prdc.dao.CompanyInfoDao;
import com.prdc.service.CompanyInfoService;

/**
 * @author Tilak R
 
 * 
 */
@Service
public class CompanyInfoServiceImpl implements CompanyInfoService{

	
	@Autowired
	private CompanyInfoDao companyInfoDao;
	
	@Override
	public String saveCompanyInfo(CompanyInfoBean companyInfoBean) {
		// TODO Auto-generated method stub
		return companyInfoDao.saveCompanyInfo(companyInfoBean);
	}

	@Override
	public List<CompanyInfoBean> getCompanyInfoList() {
		// TODO Auto-generated method stub
		return companyInfoDao.getCompanyInfoList();
	}

	@Override
	public List<CompanyInfoBean> getCompanyInfoDetails(String id) {
		// TODO Auto-generated method stub
		return companyInfoDao.getCompanyInfoDetails(id);
	}

	@Override
	public String updateCompanyInfoDetails(CompanyInfoBean companyInfoBean) {
		// TODO Auto-generated method stub
		return companyInfoDao.updateCompanyInfoDetails(companyInfoBean);
	}

	@Override
	public List<CompanyInfoBean> getSellerCompany() {
		// TODO Auto-generated method stub
		return companyInfoDao.getSellerCompany();
	}

	@Override
	public List<CompanyInfoBean> getBuyerCompany() {
		// TODO Auto-generated method stub
		return companyInfoDao.getBuyerCompany();
	}

	@Override
	public List<CompanyInfoBean> getTraderCompany() {
		// TODO Auto-generated method stub
		return companyInfoDao.getTraderCompany();
	}
}
