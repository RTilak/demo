package com.prdc.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prdc.bean.DayAhedReserveBean;
import com.prdc.bean.UnitGenerationBean;
import com.prdc.dao.AjaxDao;
import com.prdc.service.AjaxService;

@Service
public class AjaxServiceImp implements AjaxService {
	
	@Autowired
	AjaxDao ajaxDao;

	@Override
	public DayAhedReserveBean chechDayAhedReserveData(DayAhedReserveBean bean) {
		return ajaxDao.chechDayAhedReserveData(bean);
	}

	@Override
	public String insertUpdateAllDayAhedReserveData(ArrayList<String> sqlQueryList) {
		return ajaxDao.insertUpdateAllDayAhedReserveData(sqlQueryList);
	}

	@Override
	public Map<String, DayAhedReserveBean> getAllReserveData() {
		// TODO Auto-generated method stub
		return ajaxDao.getAllReserveData();
	}

	@Override
	public Map<String, List<DayAhedReserveBean>> getAllReserveData(Date time) {
		// TODO Auto-generated method stub
		return ajaxDao.getAllReserveData(time);
	}
	
	@Override
	public Map<String, UnitGenerationBean> getAllUnitGeneration() {
		// TODO Auto-generated method stub
		return ajaxDao.getAllUnitGeneration();
	}

}
