package com.prdc.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.prdc.bean.DayAhedReserveBean;
import com.prdc.bean.UnitGenerationBean;

public interface AjaxService {

	public DayAhedReserveBean chechDayAhedReserveData(DayAhedReserveBean bean);
	
	public Map<String,DayAhedReserveBean> getAllReserveData();
	
	public String insertUpdateAllDayAhedReserveData(ArrayList<String> sqlQueryList);

	public Map<String, List<DayAhedReserveBean>> getAllReserveData(Date time);
	
	public Map<String, UnitGenerationBean> getAllUnitGeneration();
	
}
