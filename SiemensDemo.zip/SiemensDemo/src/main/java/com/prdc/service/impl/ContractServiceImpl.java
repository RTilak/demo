package com.prdc.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prdc.bean.ContractBean;
import com.prdc.dao.ContractDao;
import com.prdc.service.ContractService;
/**
 * @author Tilak R
 
 * 
 */
@Service
public class ContractServiceImpl implements ContractService{
	
	@Autowired
	private ContractDao contractDao;

	@Override
	public String insertContract(ContractBean cb) {
		// TODO Auto-generated method stub
		return contractDao.insertContract(cb);
	}
	
	@Override
	public List<ContractBean> getContractList() {
		// TODO Auto-generated method stub
		return contractDao.getContractList();
	}

	@Override
	public List<ContractBean> getContractInfoDetails(String id) {
		// TODO Auto-generated method stub
		return contractDao.getContractInfoDetails(id);
	}

	@Override
	public String updateContract(ContractBean cb) {
		// TODO Auto-generated method stub
		return contractDao.updateContract(cb);
	}
}
