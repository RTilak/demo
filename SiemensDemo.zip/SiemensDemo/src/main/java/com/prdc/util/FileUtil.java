package com.prdc.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.web.multipart.MultipartFile;

public class FileUtil {

	public static void downloadFile(HttpServletRequest req, HttpServletResponse response, String fileDir, String fileName, String displayName){
//		System.out.println("filePath : : "+fileDir);
		String filePath = fileDir+fileName;
		fileName = fileName.replaceAll("\\s+", "");
//		System.out.println("fileName : : "+fileName);
		ServletOutputStream out = null;
		try {
			String mimeType = req.getServletContext().getMimeType(filePath);
			File f = new File(filePath);
			byte[] data = getFileInBytes(f);
			if (mimeType != null && !mimeType.trim().equals("")) {
				response.setContentType(mimeType);
			} else {
				response.setContentType("application/force-download");
			}
			response.setHeader("Content-Disposition", "attachment; filename=" + displayName);
			out = response.getOutputStream();
			out.write(data);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			IOUtils.closeQuietly(out);
		} 		
	}

	public static void downloadFile(HttpServletRequest req, HttpServletResponse response, String fileDir, String fileName){
//		System.out.println("filePath : : "+fileDir);
		String filePath = fileDir+fileName;
		fileName = fileName.replaceAll("\\s+", "");
//		System.out.println("fileName : : "+fileName);
		ServletOutputStream out = null;
		try {
			String mimeType = req.getServletContext().getMimeType(filePath);
			File f = new File(filePath);
			byte[] data = getFileInBytes(f);
			if (mimeType != null && !mimeType.trim().equals("")) {
				response.setContentType(mimeType);
			} else {
				response.setContentType("application/force-download");
			}
			response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
			out = response.getOutputStream();
			out.write(data);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			IOUtils.closeQuietly(out);
		} 
	}

	public static byte[] getFileInBytes(File f) throws IOException {
		FileInputStream fis = new FileInputStream(f);
		byte[] fbytes = new byte[(int) f.length()];
		fis.read(fbytes);
		fis.close();
		return fbytes;
	}

	public static void saveFile(MultipartFile file, String outputDir) throws IOException{
		if(file != null && file.getOriginalFilename() != null && !file.getOriginalFilename().isEmpty() && outputDir != null && !outputDir.isEmpty()){
			String fileName = file.getOriginalFilename();
			File f = new File(outputDir);
			if(!f.exists())f.mkdirs();		

			FileOutputStream fileOutputStream = new FileOutputStream(outputDir+fileName);
			fileOutputStream.write(file.getBytes());
			fileOutputStream.close();
		}
	}

	public static void makeDirIfNotExist(String filePath){
		File f = new File(filePath);
		if (!f.exists()) {
			f.mkdirs();
		}
	}

	public static void viewFile(HttpServletRequest req, HttpServletResponse response, String fileDir, String fileName){
		System.out.println("filePath : : "+fileDir);
		String filePath = fileDir+fileName;
		fileName = fileName.replaceAll("\\s+", "");
		System.out.println("fileName : : "+fileName);
		ServletOutputStream out = null;
		try {
			String mimeType = req.getServletContext().getMimeType(filePath);
			File f = new File(filePath);
			byte[] data = getFileInBytes(f);
			if (mimeType != null && !mimeType.trim().equals("")) {
				response.setContentType(mimeType);
			} else {
				response.setContentType("application/force-download");
			}
			response.setHeader("Content-Disposition", "inline; filename=" + fileName);
			out = response.getOutputStream();
			out.write(data);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			IOUtils.closeQuietly(out);
		} 
	}

	public static void saveFile(String fileName, String outputDir, File file) throws IOException{
		if(fileName != null && !fileName.isEmpty() && outputDir != null && !outputDir.isEmpty()){
			File f = new File(outputDir+"/");
			if(!f.exists())f.mkdirs();		

			FileOutputStream fileOutputStream = new FileOutputStream(outputDir+fileName);
			fileOutputStream.write(getFileInBytes(file));
			fileOutputStream.close();
		}
	}

	public static void removeFile(String fileName){
		File file = new File(fileName);
		file.delete();
	}

	public static void downloadNewFile(HttpServletRequest req, HttpServletResponse response, String fileName, byte[] bytes){
		try {
			String mimeType = req.getServletContext().getMimeType(fileName);
			if (mimeType != null && !mimeType.trim().equals("")) {
				response.setContentType(mimeType);
			} else {
				response.setContentType("application/force-download");
			}
			response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
			IOUtils.copy(new ByteArrayInputStream(bytes), response.getOutputStream());
			response.flushBuffer();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	
	public static List<File> getFilesRecursively(String baseFolder){
		List<File> files = new ArrayList<File>();
		File fol = new File(baseFolder);
		if(fol.exists()){
			for(File f : fol.listFiles()){
				if(f.isDirectory()){
					files.addAll(getFilesRecursively(f.getAbsolutePath()));
				}else{
					files.add(f);
				}
			}
		}		
		return files;
	}
	
	public static Map<String, File> getFileMapRecursively(String baseFolder){
		Map<String, File> fileMap = new HashMap<String, File>();
		File fol = new File(baseFolder);
		if(fol.exists()){
			for(File f : fol.listFiles()){
				if(f.isDirectory()){
					fileMap.putAll(getFileMapRecursively(f.getAbsolutePath()));
				}else{
					fileMap.put(f.getName(), f);
				}
			}
		}		
		return fileMap;
	}
}
