package com.prdc.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 * @author Tilak R
 
 * 
 */
public class DateUtil {
	
	public static Date convertStringToDate(String date,String pattern) {
		SimpleDateFormat sdf=new SimpleDateFormat(pattern);
		try {
			return  sdf.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public static String convertDateToString(Date date,String pattern) {
		SimpleDateFormat sdf=new SimpleDateFormat(pattern);
		return  sdf.format(date);
	}
}
