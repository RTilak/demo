package com.prdc.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.prdc.bean.ContractBean;
import com.prdc.enums.AnciliaryTypeEnum;
import com.prdc.enums.ContractType;
import com.prdc.enums.EnergyTypeEnum;
import com.prdc.service.ContractService;
import com.prdc.util.DateUtil;
/**
 * @author Tilak R
 
 * 
 */
@Controller
public class ContractController {
	
	@Autowired
	private ContractService contractService;
	
	
	@RequestMapping(value="/contractInfo",method= {RequestMethod.GET,RequestMethod.POST})
	private String companyInfo(Model model){
		return "contractInfo";
	}
	
	@RequestMapping(value="/insertContract" ,method= {RequestMethod.GET,RequestMethod.POST})
	public @ResponseBody String insertContract(@RequestParam(name="new-form-contract-no") String contractNo ,@RequestParam(name="new-form-contract-type") String contractType ,
			@RequestParam(name="new-form-contract-energy-type") String energyType ,@RequestParam(name="new-form-contract-anciliary-type") String anciliaryType ,
			@RequestParam(name="new-form-start-date-time") String startDate ,@RequestParam(name="new-form-end-date-time") String endDate ,
			@RequestParam(name="new-form-buyer") String buyer ,@RequestParam(name="new-form-seller") String seller ,
			@RequestParam(name="new-form-trader") String trader ,@RequestParam(name="new-form-currency") String currency ,
			@RequestParam(name="new-form-cost") String cost ,@RequestParam(name="new-form-penalty") String penalty ,
			@RequestParam(name="new-form-time-interval") String timeInterval ,@RequestParam(name="new-form-ramping-capacity",required=false,defaultValue="") String ramping  ,
			//@RequestParam(name="new-form-scheduling-intervals",required=false,defaultValue="") String scheduleIntervals ,
			//@RequestParam(name="new-form-max-reserve-value",required=false,defaultValue="") String maxReserveValue  ,
			@RequestParam(name="new-form-start-up-time",required=false,defaultValue="") String startUpTime ,@RequestParam(name="new-form-start-up-cost",required=false,defaultValue="") String startUpCost  ,Model model) {
		
		ContractBean cb=new ContractBean();
		cb.setBuyerId(buyer);
		cb.setContractNo(contractNo);
		cb.setContractType(contractType);
		cb.setContractSubType((ContractType.getEnum(contractType).compareTo(ContractType.ENERGY)==0)?EnergyTypeEnum.getEnum(energyType).getIdentifier():AnciliaryTypeEnum.getEnum(anciliaryType).getIdentifier());
		cb.setCostCurrencyPerUnit(cost);
		cb.setCurrencyUnit(currency);
		cb.setEndDateTime(DateUtil.convertStringToDate(endDate, "dd-MM-yyyy hh:mm a"));
		// cb.setFrampingCapacity(ramping);
		cb.setEnergyRampingMW(ramping);
		cb.setPenaltyCurrencyPerUnit(penalty);
		cb.setSellerId(seller);
		cb.setStartDateTime(DateUtil.convertStringToDate(startDate, "dd-MM-yyyy hh:mm a"));
		cb.setTimeInterval(timeInterval);
		cb.setTraderId(trader);
//		cb.setAnciliaryMaxReserveMW(maxReserveValue.equalsIgnoreCase("")?null:maxReserveValue);
		cb.setAnciliaryStartUpCost(startUpCost.equalsIgnoreCase("")?null:startUpCost);
		cb.setAnciliaryStartUpTime(startUpTime.equalsIgnoreCase("")?null:startUpTime);
//		cb.setEnergySchInterval(scheduleIntervals.equalsIgnoreCase("")?null:scheduleIntervals);
		
		return contractService.insertContract(cb);
	}
	
	@RequestMapping(value="/updateContract" ,method= {RequestMethod.GET,RequestMethod.POST})
	public @ResponseBody String updateContract(@RequestParam(name="new-form-contract-no") String contractNo ,@RequestParam(name="new-form-contract-type") String contractType ,
			@RequestParam(name="new-form-contract-energy-type") String energyType ,@RequestParam(name="new-form-contract-anciliary-type") String anciliaryType ,
			@RequestParam(name="new-form-start-date-time") String startDate ,@RequestParam(name="new-form-end-date-time") String endDate ,
			@RequestParam(name="new-form-buyer") String buyer ,@RequestParam(name="new-form-seller") String seller ,
			@RequestParam(name="new-form-trader") String trader ,@RequestParam(name="new-form-currency") String currency ,
			@RequestParam(name="new-form-cost") String cost ,@RequestParam(name="new-form-penalty") String penalty ,
			@RequestParam(name="new-form-time-interval") String timeInterval ,@RequestParam(name="new-form-ramping-capacity",required=false,defaultValue="") String ramping,
			//@RequestParam(name="new-form-scheduling-intervals",required=false,defaultValue="") String scheduleIntervals ,
			//@RequestParam(name="new-form-max-reserve-value",required=false,defaultValue="") String maxReserveValue  ,
			@RequestParam(name="new-form-start-up-time",required=false,defaultValue="") String startUpTime ,@RequestParam(name="new-form-start-up-cost",required=false,defaultValue="") String startUpCost  ,@RequestParam(name="id" ,required=false,defaultValue="")String id,Model model) {
		
		ContractBean cb=new ContractBean();
		cb.setId(id);
		cb.setBuyerId(buyer);
		cb.setContractNo(contractNo);
		cb.setContractType(contractType);
		cb.setContractSubType((ContractType.getEnum(contractType).compareTo(ContractType.ENERGY)==0)?EnergyTypeEnum.getEnum(energyType).getIdentifier():AnciliaryTypeEnum.getEnum(anciliaryType).getIdentifier());
		cb.setCostCurrencyPerUnit(cost);
		cb.setCurrencyUnit(currency);
		cb.setEndDateTime(DateUtil.convertStringToDate(endDate, "dd-MM-yyyy hh:mm a"));
		// cb.setFrampingCapacity(ramping);
		cb.setEnergyRampingMW(ramping);
		cb.setPenaltyCurrencyPerUnit(penalty);
		cb.setSellerId(seller);
		cb.setStartDateTime(DateUtil.convertStringToDate(startDate, "dd-MM-yyyy hh:mm a"));
		cb.setTimeInterval(timeInterval);
		cb.setTraderId(trader);
//		cb.setAnciliaryMaxReserveMW(maxReserveValue.equalsIgnoreCase("")?null:maxReserveValue);
		cb.setAnciliaryStartUpCost(startUpCost.equalsIgnoreCase("")?null:startUpCost);
		cb.setAnciliaryStartUpTime(startUpTime.equalsIgnoreCase("")?null:startUpTime);
//		cb.setEnergySchInterval(scheduleIntervals.equalsIgnoreCase("")?null:scheduleIntervals);
		
		return contractService.updateContract(cb);
	}
	
	@RequestMapping(value="/getContractList" ,method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody List<ContractBean> getContractList(Model model){
		return contractService.getContractList();
	}
	
	@RequestMapping(value="/getContractInfoDetails" ,method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody ContractBean getContractInfoDetails(@RequestParam(name="id")String id ,Model model){
		List<ContractBean> list=contractService.getContractInfoDetails(id);
		System.out.println(list);
		return !list.isEmpty()?list.get(0):null;
	}
	public static void main(String[] args) {
		/*try {
			Runtime rt = Runtime.getRuntime();
			//Runtime.getRuntime().exec("C:\\Program Files\\Notepad++\\notepad++.exe", null, new File("D:\\"));
//			Process process = new ProcessBuilder("C:\\Program Files\\Notepad++\\notepad++.exe").start();
			Process pr = rt.exec("C:\\Program Files\\Notepad++\\notepad++.exe");
			 
            BufferedReader input = new BufferedReader(new InputStreamReader(pr.getInputStream()));

            String line=null;

            while((line=input.readLine()) != null) {
                System.out.println(line);
            }

            int exitVal = pr.waitFor();
            System.out.println("Exited with error code "+exitVal);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
}
