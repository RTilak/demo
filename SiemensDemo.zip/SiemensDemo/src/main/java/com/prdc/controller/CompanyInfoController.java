package com.prdc.controller;

import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.prdc.bean.CompanyInfoBean;
import com.prdc.enums.CompanyType;
import com.prdc.service.CompanyInfoService;
/**
 * @author Tilak R
 
 * 
 */
@Controller
public class CompanyInfoController {
	
	@Autowired
	private CompanyInfoService companyInfoService;
	
	@RequestMapping(value="/companyInfo")
	private String companyInfo(Model model){
		return "companyInfo";
	}
	
	@RequestMapping(value="/insertCompanyInfo" ,method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody String insertCompanyInfo(@RequestParam(name="new-form-name")String name ,@RequestParam(name="new-form-countries")String country ,
			@RequestParam(name="new-form-states")String state ,@RequestParam(name="new-form-address")String address ,@RequestParam(name="new-form-email")String mail ,
			@RequestParam(name="new-form-phone-no")String phoneNo ,@RequestParam(name="new-form-max-sell-capacity")String maxSellCapacity , @RequestParam(name="new-form-max-sell-reserve")String maxSellReserve,@RequestParam(name="new-form-max-buy-capacity")String maxBuyCapacity 
			, @RequestParam(name="new-form-max-buy-reserve")String maxBuyReserve,@RequestParam(name="new-form-company-type" ,required=false,defaultValue="")String companyType ,Model model){
		
		
		CompanyInfoBean companyInfoBean=new CompanyInfoBean();
		companyInfoBean.setCompanyType(CompanyType.getEnum(companyType));
		companyInfoBean.setAddress(address);
		companyInfoBean.setCountry(country);
		companyInfoBean.setEmail(mail);
		companyInfoBean.setMaxBuyCapacity((maxBuyCapacity!=null && !maxBuyCapacity.isEmpty())?Double.valueOf(maxBuyCapacity):0);
		companyInfoBean.setMaxSellCapacity((maxSellCapacity!=null && !maxSellCapacity.isEmpty())?Double.valueOf(maxSellCapacity):0);
		companyInfoBean.setMaxBuyReserve((maxBuyReserve!=null && !maxBuyReserve.isEmpty())?Double.valueOf(maxBuyReserve):0);
		companyInfoBean.setMaxSellReserve((maxSellReserve!=null && !maxSellReserve.isEmpty())?Double.valueOf(maxSellReserve):0);
		companyInfoBean.setName(name);
		companyInfoBean.setPhoneNo(phoneNo);
		companyInfoBean.setState(state);
		
		return companyInfoService.saveCompanyInfo(companyInfoBean);
//		return "companyInfo";
	}
	
	@RequestMapping(value="/getCompanyInfoList" ,method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody List<CompanyInfoBean> getCompanyInfoList(Model model){
		return companyInfoService.getCompanyInfoList();
	}
	
	@RequestMapping(value="/getCompanyInfoDetails" ,method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody CompanyInfoBean getCompanyInfoDetails(@RequestParam(name="id")String id ,Model model){
		List<CompanyInfoBean> list=companyInfoService.getCompanyInfoDetails(id);
		return !list.isEmpty()?list.get(0):null;
	}
	
	@RequestMapping(value="/updateCompanyInfoDetails" ,method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody String updateCompanyInfoDetails(@RequestParam(name="new-form-name")String name ,@RequestParam(name="new-form-countries")String country ,
			@RequestParam(name="new-form-states")String state ,@RequestParam(name="new-form-address")String address ,@RequestParam(name="new-form-email")String mail ,
			@RequestParam(name="new-form-phone-no")String phoneNo ,@RequestParam(name="new-form-max-sell-capacity")String maxSellCapacity ,@RequestParam(name="new-form-max-sell-reserve")String maxSellReserve ,@RequestParam(name="new-form-max-buy-capacity")String maxBuyCapacity 
			,@RequestParam(name="new-form-max-buy-reserve")String maxBuyReserve ,@RequestParam(name="new-form-company-type" ,required=false,defaultValue="")String companyType ,@RequestParam(name="id" ,required=false,defaultValue="")String id ,Model model){
		CompanyInfoBean companyInfoBean=new CompanyInfoBean();
		companyInfoBean.setCompanyType(CompanyType.getEnum(companyType));
		companyInfoBean.setAddress(address);
		companyInfoBean.setCountry(country);
		companyInfoBean.setEmail(mail);
		companyInfoBean.setMaxBuyCapacity((maxBuyCapacity!=null && !maxBuyCapacity.isEmpty())?Double.valueOf(maxBuyCapacity):0);
		companyInfoBean.setMaxSellCapacity((maxSellCapacity!=null && !maxSellCapacity.isEmpty())?Double.valueOf(maxSellCapacity):0);
		companyInfoBean.setMaxBuyReserve((maxBuyReserve!=null && !maxBuyReserve.isEmpty())?Double.valueOf(maxBuyReserve):0);
		companyInfoBean.setMaxSellReserve((maxSellReserve!=null && !maxSellReserve.isEmpty())?Double.valueOf(maxSellReserve):0);
		companyInfoBean.setName(name);
		companyInfoBean.setPhoneNo(phoneNo);
		companyInfoBean.setState(state);
		companyInfoBean.setId(id);
		return companyInfoService.updateCompanyInfoDetails(companyInfoBean);
	}
	
	@RequestMapping(value="/getSellerBuyerTraderCompanies" ,method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody String getSellerBuyerTraderCompany(Model model){
		JSONObject jsonObj=new JSONObject();
		jsonObj.put("seller", companyInfoService.getSellerCompany());
		jsonObj.put("buyer", companyInfoService.getBuyerCompany());
		jsonObj.put("trader", companyInfoService.getTraderCompany());
		return jsonObj.toString();
	}
	
	@RequestMapping(value="/getSellerCompanies" ,method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody List<CompanyInfoBean> getSellerCompany(Model model){
		return companyInfoService.getSellerCompany();
	}
	
	@RequestMapping(value="/getBuyerCompanies" ,method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody List<CompanyInfoBean> getBuyerCompany(Model model){
		return companyInfoService.getBuyerCompany();
	}
	
	@RequestMapping(value="/getTraderCompanies" ,method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody List<CompanyInfoBean> getTraderCompany(Model model){
		return companyInfoService.getTraderCompany();
	}
}
