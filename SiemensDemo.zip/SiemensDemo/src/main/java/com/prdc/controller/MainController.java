package com.prdc.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.prdc.bean.CompanyInfoBean;
import com.prdc.bean.ContractBean;
import com.prdc.bean.DayAhedReserveBean;
import com.prdc.bean.EmployeeDto;
import com.prdc.bean.UnitGenerationBean;
import com.prdc.enums.AnciliaryTypeEnum;
import com.prdc.enums.ContractType;
import com.prdc.enums.EnergyTypeEnum;
import com.prdc.service.AjaxService;
import com.prdc.service.CompanyInfoService;
import com.prdc.service.ContractService;
import com.prdc.service.MainService;
import com.prdc.util.DateUtil;
import com.prdc.util.FileUtil;


/**
 * @author Tilak R
 
 * 
 */

@Controller
public class MainController {
	
	@Autowired
	private MainService mainService;
	
	@Autowired
	private AjaxService ajaxService;
	
	@Autowired
	private ContractService contractService;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private CompanyInfoService companyInfoService;
	
	
	@RequestMapping(value="/get")
	private @ResponseBody List<String> getValues(Model model){
		return mainService.getValues();
	}
	
	@RequestMapping(value="/uploadsInfo",method= {RequestMethod.GET,RequestMethod.POST})
	private String companyInfo(Model model){
		return "uploadsInfo";
	}
	
	@RequestMapping(value="/lfaModuel",method= {RequestMethod.GET,RequestMethod.POST})
	private String lfaModuel(Model model){
		return "lfaModuel";
	}
	
	@RequestMapping(value="/saveUploadData",method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody String saveUploadData(@RequestParam(name="data")String data, @RequestParam(name="headers")String headers, 
			@RequestParam(name="trntype")String trntype, Model model){
		
		try {
//			int counter = 1,newCounter = 0;
			JSONArray headerJson = new JSONArray(headers);
			JSONArray dataJson = new JSONArray(data);
			JSONArray tempArray;
			System.out.println(headers);
			System.out.println(data);
			ArrayList<String> sqlQueryList = new ArrayList<String>();
			String[] temp;
			Map<String, DayAhedReserveBean> map=ajaxService.getAllReserveData();
			
			for(int k=0; k<dataJson.length();k++) {
				tempArray = dataJson.getJSONArray(k);
				for(int i=0; i<headerJson.length(); i++) {
					temp = (tempArray.get(1).toString()).split("-");
					DayAhedReserveBean bean = new DayAhedReserveBean();
					bean.setBlockDateTime(DateUtil.convertStringToDate((temp[0]+"-"+temp[1]+"-"+temp[2]), "dd-MM-yyyy HH:mm"));
					bean.setContractId(headerJson.get(i).toString());
					bean.setType(trntype);
					bean.setInternalEnergyInput(tempArray.get(i+2).toString());
					bean.setInternalReserveInput(tempArray.get(i+2).toString());
					bean.setExternalEnergyInput(tempArray.get(i+2).toString());
					bean.setExternalReserveInput(tempArray.get(i+2).toString());
					
//					if(ajaxService.chechDayAhedReserveData(bean) != null) {
					if(map.get(bean.getContractId()+" "+bean.getBlockDateTime())!= null) {
						if(("1").equals(trntype))
							sqlQueryList.add("UPDATE ITES_DAY_AHEAD_ENERGY_RESERVE SET FINTERNAL_ENERGY = "+bean.getInternalEnergyInput()+" WHERE IREFID_CONTRACT = "+bean.getContractId()+" AND TBLOCK_DATE_TIME = '"+bean.getBlockDateTime()+"';");
						else if(("2").equals(trntype))
							sqlQueryList.add("UPDATE ITES_DAY_AHEAD_ENERGY_RESERVE SET FINTERNAL_RESERVE = "+bean.getInternalReserveInput()+" WHERE IREFID_CONTRACT = "+bean.getContractId()+" AND TBLOCK_DATE_TIME = '"+bean.getBlockDateTime()+"';");
						else if(("3").equals(trntype))
							sqlQueryList.add("UPDATE ITES_DAY_AHEAD_ENERGY_RESERVE SET FEXTERNAL_ENERGY = "+bean.getExternalEnergyInput()+" WHERE IREFID_CONTRACT = "+bean.getContractId()+" AND TBLOCK_DATE_TIME = '"+bean.getBlockDateTime()+"';");
						else
							sqlQueryList.add("UPDATE ITES_DAY_AHEAD_ENERGY_RESERVE SET FEXTERNAL_RESERVE = "+bean.getExternalReserveInput()+" WHERE IREFID_CONTRACT = "+bean.getContractId()+" AND TBLOCK_DATE_TIME = '"+bean.getBlockDateTime()+"';");
					}
					else {
						if(("1").equals(trntype))
							sqlQueryList.add("INSERT INTO ITES_DAY_AHEAD_ENERGY_RESERVE (IREFID_CONTRACT, TBLOCK_DATE_TIME, FINTERNAL_ENERGY) VALUES ("+bean.getContractId()+", '"+bean.getBlockDateTime()+"', "+bean.getInternalEnergyInput()+");");
						else if(("2").equals(trntype))
							sqlQueryList.add("INSERT INTO ITES_DAY_AHEAD_ENERGY_RESERVE (IREFID_CONTRACT, TBLOCK_DATE_TIME, FINTERNAL_RESERVE) VALUES ("+bean.getContractId()+", '"+bean.getBlockDateTime()+"', "+bean.getInternalReserveInput()+");");
						else if(("3").equals(trntype))
							sqlQueryList.add("INSERT INTO ITES_DAY_AHEAD_ENERGY_RESERVE (IREFID_CONTRACT, TBLOCK_DATE_TIME, FEXTERNAL_ENERGY) VALUES ("+bean.getContractId()+", '"+bean.getBlockDateTime()+"', "+bean.getExternalEnergyInput()+");");
						else
							sqlQueryList.add("INSERT INTO ITES_DAY_AHEAD_ENERGY_RESERVE (IREFID_CONTRACT, TBLOCK_DATE_TIME, FEXTERNAL_RESERVE) VALUES ("+bean.getContractId()+", '"+bean.getBlockDateTime()+"', "+bean.getExternalReserveInput()+");");
					}
				}
			}
			if(sqlQueryList != null && sqlQueryList.size() > 0)
				return ajaxService.insertUpdateAllDayAhedReserveData(sqlQueryList);
			else
				return "error";
			
		}
		catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			return "exceptipn";
		}
	}
	
	@RequestMapping(value="/getRevisonData",method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody String getRevisonData(@RequestParam(name="revisonType")String revisonType, Model model){
		Calendar c = Calendar.getInstance();
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.add(Calendar.DATE, 1);
		JSONArray headerJson = new JSONArray();
		JSONArray dataJson = new JSONArray();
		JSONArray tempArray;
		JSONObject obj = new JSONObject();
		
		String temp1 = "", temp2 = "";

		headerJson.put("Block No");
		if(("1").equals(revisonType)) {
			headerJson.put("Contract No<br>Buyer<br>Seller<br>Trader");
		}
		else {
			headerJson.put("Plant No.<br>Unit No.<br>Unit Name<br>Unit Cost / MWhr");
		}
		List<ContractBean> contractorList = contractService.getContractList();
		Map<String, UnitGenerationBean> unitMap = ajaxService.getAllUnitGeneration();
		Map<String, UnitGenerationBean> unitMapUnique=new HashMap<>();
		for(String list:unitMap.keySet()) {
			UnitGenerationBean ug=unitMap.get(list);
			//unitMapUnique.put("Unit-"+ug.getUnitId()+"<br>Plant-"+ug.getPlantId()+"<br>G.Type-"+ug.getGeneratorType(), ug);
			unitMapUnique.put(ug.getUnitId()+":"+ug.getPlantId()+":"+ug.getGeneratorType(), ug);
		}
		
		ContractBean bean;
		Map<String, DayAhedReserveBean> map=ajaxService.getAllReserveData();
		for(int i=0; i<96; i++) {
			temp1 = DateUtil.convertDateToString(c.getTime(), "dd-MM-yyyy HH:mm");
			c.add(Calendar.MINUTE, 15);
			temp2 = temp1 + "-" +DateUtil.convertDateToString(c.getTime(), "HH:mm");
			if(("1").equals(revisonType)) {
				tempArray = new JSONArray();
				for(int k =0; k<contractorList.size(); k++) {
					bean=contractorList.get(k);
					if(i == 0) {
						headerJson.put(bean.getContractNo()+"<br>"+bean.getBuyerName()+"<br>"+bean.getSellerName()+"<br>"+bean.getTraderName()+"<span>"+bean.getId()+"</span>");
					}
					if(k==0) {
						tempArray.put(i+"");
						tempArray.put(temp2);
					}
					if(map.get(bean.getId()+" "+temp1)!= null) {
						tempArray.put(map.get(bean.getId()+" "+temp1).getTransactionValue()!=null?map.get(bean.getId()+" "+temp1).getTransactionValue():"0");
					}else {
						tempArray.put("0");
					}
				}
				dataJson.put(tempArray);
			}
			else {
				tempArray = new JSONArray();
				int k = 0;
				for(String headerUnique:unitMapUnique.keySet()) {					
					if(i == 0) {
						headerJson.put("Unit-"+headerUnique.split(":")[0]+"<br>Plant-"+headerUnique.split(":")[1]+"<br>G.Type-"+headerUnique.split(":")[2]);
					}
					if(k==0) {
						tempArray.put(i+"");
						tempArray.put(temp2);
					}
					if(unitMap.get(headerUnique.split(":")[2]+" "+headerUnique.split(":")[1]+" "+headerUnique.split(":")[0]+" "+temp1)!= null) {
						tempArray.put(unitMap.get(headerUnique.split(":")[0]+" "+headerUnique.split(":")[0]+" "+headerUnique.split(":")[0]+" "+temp1).getValue()!=null?unitMap.get(headerUnique.split(":")[0]+" "+headerUnique.split(":")[0]+" "+headerUnique.split(":")[0]+" "+temp1).getValue():"0");
					}else {
						tempArray.put("0");
					}
					k++;
				}
				dataJson.put(tempArray);
			}
		}
		
		obj.put("data", dataJson);
		obj.put("header", headerJson);
		
		return obj.toString();
	}
	
	@RequestMapping(value="/getUploadData",method= {RequestMethod.GET,RequestMethod.POST})
	private @ResponseBody String getUploadData(@RequestParam(name="trntype")String trntype, Model model){
		Calendar c = Calendar.getInstance();
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.add(Calendar.DATE, 1);
		JSONArray headerJson = new JSONArray();
		JSONArray dataJson = new JSONArray();
		JSONArray tempArray;
		JSONObject obj = new JSONObject();
		
		List<ContractBean> contractorList = contractService.getContractList();
		
		String temp1 = "", temp2 = "";
		headerJson.put("Block No");
		headerJson.put("Contract No<br>Buyer<br>Seller<br>Trader");
		Map<String, DayAhedReserveBean> map=ajaxService.getAllReserveData();
//		System.out.println(map);
		for(int i=0; i<96; i++) {
			temp1 = DateUtil.convertDateToString(c.getTime(), "dd-MM-yyyy HH:mm");
			temp2 = temp1 + "-" +DateUtil.convertDateToString(c.getTime(), "HH:mm");
			tempArray = new JSONArray();
			for(int k =0; k<contractorList.size(); k++) {
				ContractBean bean = contractorList.get(k);
				DayAhedReserveBean dBean = new DayAhedReserveBean();
				dBean.setContractId(bean.getId());
				dBean.setBlockDateTime(DateUtil.convertStringToDate(temp1, "dd-MM-yyyy HH:mm"));
//				System.out.println("before-"+dBean);
//				dBean = ajaxService.chechDayAhedReserveData(dBean);
//				System.out.println("-after ajax-"+dBean);
//				DayAhedReserveBean dBean1 = map.get(dBean.getContractId()+" "+dBean.getBlockDateTime());
//				System.out.println("map--"+dBean1);
//				System.out.println("---"+dBean);
				dBean = map.get(dBean.getContractId()+" "+dBean.getBlockDateTime());
				if(i == 0) {
					headerJson.put(bean.getContractNo()+"<br>"+bean.getBuyerName()+"<br>"+bean.getSellerName()+"<br>"+bean.getTraderName()+"<span>"+bean.getId()+"</span>");
				}
				if(k==0) {
					tempArray.put(i+"");
					tempArray.put(temp2);
//					System.out.println(dBean);
					if(dBean == null)
						tempArray.put("0");
					else {
						if(("1").equals(trntype))
							tempArray.put(dBean.getInternalEnergyInput());
						else if(("2").equals(trntype))
							tempArray.put(dBean.getInternalReserveInput());
						else if(("3").equals(trntype))
							tempArray.put(dBean.getExternalEnergyInput());
						else
							tempArray.put(dBean.getExternalReserveInput());
					}
				}
				else {
					if(dBean == null)
						tempArray.put("0");
					else {
						if(("1").equals(trntype))
							tempArray.put(dBean.getInternalEnergyInput());
						else if(("2").equals(trntype))
							tempArray.put(dBean.getInternalReserveInput());
						else if(("3").equals(trntype))
							tempArray.put(dBean.getExternalEnergyInput());
						else
							tempArray.put(dBean.getExternalReserveInput());
					}
				}
			}
			dataJson.put(tempArray);
			c.add(Calendar.MINUTE, 15);
		}
		
		obj.put("data", dataJson);
		obj.put("header", headerJson);
		
		return obj.toString();
	}
	
	@RequestMapping(value="/generateInputFile",method= {RequestMethod.GET,RequestMethod.POST})
	public  String generateInputFile(Model model,HttpServletRequest req,HttpServletResponse response) {
		String fs=System.getProperty("file.separator");
		String fileLocation=env.getProperty("inputFileLocation");
		String ls=System.lineSeparator();
		File f=new File(fileLocation);
		if(!f.exists()) {
			f.mkdirs();
		}
		f=new File(fileLocation+fs+"inputFile.txt");
		try {
			f.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Calendar c = Calendar.getInstance();
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.add(Calendar.DATE, 1);
		List<CompanyInfoBean> companyList=companyInfoService.getCompanyInfoList();
		List<ContractBean> contractList=contractService.getContractList();
		Map<String, List<DayAhedReserveBean>> map=ajaxService.getAllReserveData(c.getTime());
		System.out.println(map);
		StringBuilder text=new StringBuilder();
		text.append("% Total no. of Companies "+ls+"% Total no. of Contracts "+ls+"% Total no. of Transactions "+ls+"% Total no. of TimeIntvlBlocks "+ls);
		text.append(""+(companyList!=null?companyList.size():0)+"\t"+(contractList!=null?contractList.size():0)+"\t"+(contractList!=null?contractList.size():0)+"\t"+"96"+ls+ls);
		text.append("% Company Details (Type : Seller / Buyer/ Trader /All - 1/2/3/4)"+ls);
		text.append("% CompanyID\tCountry\tType\tMaxBuyingCapacity\tMaxSellingCapacity\tMaxSellReserve\tMaxBuyReserve"+ls);
		for(CompanyInfoBean list:companyList) {
			text.append(list.getId()+"\t"+list.getCountry()+"\t"+list.getCompanyType().getIdentifier()+"\t"+(list.getMaxBuyCapacity()!=null?list.getMaxBuyCapacity():0)+"\t"+(list.getMaxSellCapacity()!=null?list.getMaxSellCapacity():0)+"\t"+(list.getMaxSellReserve()!=null?list.getMaxSellReserve():0)+"\t"+(list.getMaxBuyReserve()!=null?list.getMaxBuyReserve():0)+ls);
		}
		text.append(ls);
		text.append("% Contract Details (Type : Energy/Ancialry- 1/2)"+ls);
		text.append("% Contract Details (Contract_SubType : SHORT/MEDIUM/LONG - Short Term Open Access/Medium Term Open Access/Long Term Open Access)"+ls);
		text.append("% Contract Details (Contract_SubType : PRIMARY/SECONDARY/TERITARY/SPINNING/NONSPINNING - Primary/Secondary/Tertiary/Spinning/Non-Spinning)"+ls);
		text.append("% ContractID\tContractType\tContract_SubType\tBuyerID\tSellerID\tCurrencyType\tCost/unit\tSch_Intvl_Min\tRamp( MW/min)"+ls);
		for(ContractBean list:contractList) {
			text.append(list.getId()+"\t");
			text.append(list.getContractType()+"\t");
			text.append((ContractType.getEnum(list.getContractType()).compareTo(ContractType.ENERGY)==0)?EnergyTypeEnum.getEnum(list.getContractSubType())+"\t":AnciliaryTypeEnum.getEnum(list.getContractSubType())+"\t");
			text.append(list.getBuyerId()+"\t");
			text.append(list.getSellerId()+"\t");
			text.append((list.getCurrencyUnit()!=null?list.getCurrencyUnit():0)+"\t");
			text.append((list.getCostCurrencyPerUnit()!=null?list.getCostCurrencyPerUnit():0)+"\t");
			text.append((list.getTimeInterval()!=null?list.getTimeInterval():0)+"\t");
			text.append((list.getEnergyRampingMW()!=null?list.getEnergyRampingMW():0)+ls);
//			text.append(list.getAnciliaryMaxReserveMW()+"\t");
//			text.append(list.getAnciliaryStartUpTime()+"\t");
//			text.append(list.getAnciliaryStartUpCost()+ls);
		}
		text.append(ls);
		text.append("% Transaction Details"+ls);
		text.append("%ContractID\tBuyer\tSeller"+ls);
		for(ContractBean list:contractList) {
			text.append(list.getId()+"\t");
			text.append(list.getBuyerId()+"\t");
			text.append(list.getSellerId()+ls);
		}
		text.append(ls);
		boolean header=true;
//		text.append("%Block\tTrans1\tTrans2");
//		text.append(ls);
		for(int i=0;i<96;i++) {
			if(header) {
				int j=1;
				text.append("%");
				for(ContractBean list:contractList) {
					text.append(list.getId());
					text.append("\t");
					text.append("\t");
				}
				text.append(ls);
				header=false;
			}
			for(ContractBean list:contractList) {
//				System.out.println(list.getId());
//				System.out.println((map.get(list.getId())!=null && !map.get(list.getId()).isEmpty() && map.get(list.getId()).size()>0));
//				text.append(((map.get(list.getId())!=null && !map.get(list.getId()).isEmpty() && map.get(list.getId()).size()>i )? map.get(list.getId()).get(i).getOutputValue()+"\t"+map.get(list.getId()).get(i).getStatusValue():0));
				text.append(((map.get(list.getId())!=null && !map.get(list.getId()).isEmpty() && map.get(list.getId()).size()>i )? map.get(list.getId()).get(i).getOutputValue():0));
				text.append("\t");
			}
			text.append(ls);
		}
		BufferedWriter bw;
		try {
			bw=new BufferedWriter(new FileWriter(f));
			bw.write(text.toString());
			bw.close();
//			return "success";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
//			return "error";
		}
		FileUtil.downloadFile(req, response, fileLocation+fs, "inputFile.txt");
		
		return null;
		
	}
//	public static void main(String[] args) {
//		String fs=System.getProperty("file.separator");
//		String fileLocation="E:\\Siemens Project\\SiemensLFC";
//		String ls=System.lineSeparator();
//		File f=new File(fileLocation);
//		if(!f.exists()) {
//			f.mkdirs();
//		}
//		f=new File(fileLocation+fs+"inputFile.txt");
//		try {
//			f.createNewFile();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
////		List<CompanyInfoBean> companyList=companyInfoService.getCompanyInfoList();
////		List<ContractBean> contractList=contractService.getContractList();
//		StringBuilder text=new StringBuilder();
//		text.append("% Total no. of Companies "+ls+" % Total no. of Contracts "+ls+" % Total no. of Transactions "+ls+" % Total no. of TimeIntvlBlocks "+ls);
////		text.append(""+(companyList));
//		BufferedWriter bw;
//		try {
//			bw=new BufferedWriter(new FileWriter(fileLocation+fs+"inputFile.txt"));
//			System.out.println("writing");
//			bw.write(text.toString());
//			bw.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
////		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileLocation+fs+"inputFile.txt"))) {
////
////			String content = "This is the content to write into file"+ls+" abcdvgd";
////
////			bw.write(content);
////			
////			// no need to close it.
////			//bw.close();
////
////			System.out.println("Done");
////
////		} catch (IOException e) {
////
////			e.printStackTrace();
////
////		}
//		System.out.println("success");
//	}
	
	@RequestMapping(value="/test",method= {RequestMethod.GET,RequestMethod.POST})
	private  String test(@ModelAttribute("employee") EmployeeDto employeeDto,BindingResult result){
		return "test";
	}
	
	@RequestMapping(value="/save",method= {RequestMethod.GET,RequestMethod.POST})
	private  String save(@Valid @ModelAttribute("employee") EmployeeDto employeeDto,BindingResult result){
		System.out.println("inside con");
	
		if(result.hasErrors()) {
			System.out.println("inside result");
			return "test";
		}
		return "test";
	}
}
