package com.prdc.bean;

import java.util.Date;

public class DayAhedReserveBean {
	private String contractId;
	private Date blockDateTime;
	private String type;
	
	private String internalEnergyInput;
	private String internalReserveInput;
	private String externalEnergyInput;
	private String externalReserveInput;
	private String statusValue;
	private String outputValue;
	private String transactionValue;
	
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	public Date getBlockDateTime() {
		return blockDateTime;
	}
	public void setBlockDateTime(Date blockDateTime) {
		this.blockDateTime = blockDateTime;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getInternalEnergyInput() {
		return internalEnergyInput;
	}
	public void setInternalEnergyInput(String internalEnergyInput) {
		this.internalEnergyInput = internalEnergyInput;
	}
	public String getInternalReserveInput() {
		return internalReserveInput;
	}
	public void setInternalReserveInput(String internalReserveInput) {
		this.internalReserveInput = internalReserveInput;
	}
	public String getExternalEnergyInput() {
		return externalEnergyInput;
	}
	public void setExternalEnergyInput(String externalEnergyInput) {
		this.externalEnergyInput = externalEnergyInput;
	}
	public String getExternalReserveInput() {
		return externalReserveInput;
	}
	public void setExternalReserveInput(String externalReserveInput) {
		this.externalReserveInput = externalReserveInput;
	}
	
	public String getOutputValue() {
		return outputValue;
	}
	public void setOutputValue(String outputValue) {
		this.outputValue = outputValue;
	}
	
	public String getStatusValue() {
		return statusValue;
	}
	public void setStatusValue(String statusValue) {
		this.statusValue = statusValue;
	}
	
	public String getTransactionValue() {
		return transactionValue;
	}
	public void setTransactionValue(String transactionValue) {
		this.transactionValue = transactionValue;
	}
	@Override
	public String toString() {
		return "DayAhedReserveBean [contractId=" + contractId + ", blockDateTime=" + blockDateTime + ", type=" + type
				+ ", internalEnergyInput=" + internalEnergyInput + ", internalReserveInput=" + internalReserveInput
				+ ", externalEnergyInput=" + externalEnergyInput + ", externalReserveInput=" + externalReserveInput
				+ ", statusValue=" + statusValue + ", outputValue=" + outputValue + ", transactionValue="
				+ transactionValue + "]";
	}
	
}
