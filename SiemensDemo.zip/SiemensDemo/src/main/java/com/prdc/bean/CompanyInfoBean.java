package com.prdc.bean;

import com.prdc.enums.CompanyType;
/**
 * @author Tilak R
 
 * 
 */
public class CompanyInfoBean {
	
	
	private String id;
	private CompanyType companyType;
	private String name;
	private String country;
	private String state;
	private String address;
	private String email;
	private String phoneNo;
	private Double maxSellCapacity;
	private Double maxBuyCapacity;
	private Double maxSellReserve;
	private Double maxBuyReserve;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Double getMaxSellCapacity() {
		return maxSellCapacity;
	}
	public void setMaxSellCapacity(Double maxSellCapacity) {
		if(this.companyType!=null && (this.companyType.compareTo(CompanyType.SELLER)==0 || this.companyType.compareTo(CompanyType.ALL)==0)) {
			this.maxSellCapacity = maxSellCapacity;
		}
	}
	public Double getMaxBuyCapacity() {
		return maxBuyCapacity;
	}
	public void setMaxBuyCapacity(Double maxBuyCapacity) {
		if(this.companyType!=null && (this.companyType.compareTo(CompanyType.BUYER)==0 || this.companyType.compareTo(CompanyType.ALL)==0)) {
			this.maxBuyCapacity = maxBuyCapacity;
		}
	}
	public CompanyType getCompanyType() {
		return companyType;
	}
	public void setCompanyType(CompanyType companyType) {
		this.companyType = companyType;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Double getMaxSellReserve() {
		return maxSellReserve;
	}
	public void setMaxSellReserve(Double maxSellReserve) {
		this.maxSellReserve = maxSellReserve;
	}
	public Double getMaxBuyReserve() {
		return maxBuyReserve;
	}
	public void setMaxBuyReserve(Double maxBuyReserve) {
		this.maxBuyReserve = maxBuyReserve;
	}
}
