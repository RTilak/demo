package com.prdc.bean;

import java.util.Date;

/**
 * @author Tilak R
 
 * 
 */
public class ContractBean {
	
	private String id;
	private String contractNo;
	private String contractType;
	private String contractSubType;
	private Date startDateTime;
	private Date endDateTime;
	private String sellerId;
	private String buyerId;
	private String traderId;
	private String currencyUnit;
	private String costCurrencyPerUnit;
	private String penaltyCurrencyPerUnit;
	private String timeInterval;
	private String frampingCapacity;
	private String energySchInterval;
	private String energyRampingMW;
	private String anciliaryMaxReserveMW;
	private String anciliaryStartUpTime;
	private String anciliaryStartUpCost;
	
	private String sStartDateTime;
	private String sEndDateTime;
	
	private String sellerName;
	private String buyerName;
	private String traderName;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getContractNo() {
		return contractNo;
	}
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getContractSubType() {
		return contractSubType;
	}
	public void setContractSubType(String contractSubType) {
		this.contractSubType = contractSubType;
	}
	public Date getStartDateTime() {
		return startDateTime;
	}
	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}
	public Date getEndDateTime() {
		return endDateTime;
	}
	public void setEndDateTime(Date endDateTime) {
		this.endDateTime = endDateTime;
	}
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}
	public String getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}
	public String getTraderId() {
		return traderId;
	}
	public void setTraderId(String traderId) {
		this.traderId = traderId;
	}
	public String getCurrencyUnit() {
		return currencyUnit;
	}
	public void setCurrencyUnit(String currencyUnit) {
		this.currencyUnit = currencyUnit;
	}
	public String getCostCurrencyPerUnit() {
		return costCurrencyPerUnit;
	}
	public void setCostCurrencyPerUnit(String costCurrencyPerUnit) {
		this.costCurrencyPerUnit = costCurrencyPerUnit;
	}
	public String getPenaltyCurrencyPerUnit() {
		return penaltyCurrencyPerUnit;
	}
	public void setPenaltyCurrencyPerUnit(String penaltyCurrencyPerUnit) {
		this.penaltyCurrencyPerUnit = penaltyCurrencyPerUnit;
	}
	public String getTimeInterval() {
		return timeInterval;
	}
	public void setTimeInterval(String timeInterval) {
		this.timeInterval = timeInterval;
	}
	public String getFrampingCapacity() {
		return frampingCapacity;
	}
	public void setFrampingCapacity(String frampingCapacity) {
		this.frampingCapacity = frampingCapacity;
	}
	public String getEnergySchInterval() {
		return energySchInterval;
	}
	public void setEnergySchInterval(String energySchInterval) {
		this.energySchInterval = energySchInterval;
	}
	public String getEnergyRampingMW() {
		return energyRampingMW;
	}
	public void setEnergyRampingMW(String energyRampingMW) {
		this.energyRampingMW = energyRampingMW;
	}
	public String getAnciliaryMaxReserveMW() {
		return anciliaryMaxReserveMW;
	}
	public void setAnciliaryMaxReserveMW(String anciliaryMaxReserveMW) {
		this.anciliaryMaxReserveMW = anciliaryMaxReserveMW;
	}
	public String getAnciliaryStartUpTime() {
		return anciliaryStartUpTime;
	}
	public void setAnciliaryStartUpTime(String anciliaryStartUpTime) {
		this.anciliaryStartUpTime = anciliaryStartUpTime;
	}
	public String getAnciliaryStartUpCost() {
		return anciliaryStartUpCost;
	}
	public void setAnciliaryStartUpCost(String anciliaryStartUpCost) {
		this.anciliaryStartUpCost = anciliaryStartUpCost;
	}
	public String getsStartDateTime() {
		return sStartDateTime;
	}
	public void setsStartDateTime(String sStartDateTime) {
		this.sStartDateTime = sStartDateTime;
	}
	public String getsEndDateTime() {
		return sEndDateTime;
	}
	public void setsEndDateTime(String sEndDateTime) {
		this.sEndDateTime = sEndDateTime;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public String getBuyerName() {
		return buyerName;
	}
	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}
	public String getTraderName() {
		return traderName;
	}
	public void setTraderName(String traderName) {
		this.traderName = traderName;
	}
	@Override
	public String toString() {
		return "ContractBean [id=" + id + ", contractNo=" + contractNo + ", contractType=" + contractType
				+ ", contractSubType=" + contractSubType + ", startDateTime=" + startDateTime + ", endDateTime="
				+ endDateTime + ", sellerId=" + sellerId + ", buyerId=" + buyerId + ", traderId=" + traderId
				+ ", currencyUnit=" + currencyUnit + ", costCurrencyPerUnit=" + costCurrencyPerUnit
				+ ", penaltyCurrencyPerUnit=" + penaltyCurrencyPerUnit + ", timeInterval=" + timeInterval
				+ ", frampingCapacity=" + frampingCapacity + ", energySchInterval=" + energySchInterval
				+ ", energyRampingMW=" + energyRampingMW + ", anciliaryMaxReserveMW=" + anciliaryMaxReserveMW
				+ ", anciliaryStartUpTime=" + anciliaryStartUpTime + ", anciliaryStartUpCost=" + anciliaryStartUpCost
				+ ", sStartDateTime=" + sStartDateTime + ", sEndDateTime=" + sEndDateTime + ", sellerName=" + sellerName
				+ ", buyerName=" + buyerName + ", traderName=" + traderName + "]";
	}
	
	
}
