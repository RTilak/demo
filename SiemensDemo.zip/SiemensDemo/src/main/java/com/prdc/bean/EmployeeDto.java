package com.prdc.bean;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;



public class EmployeeDto {
	
	@NotNull(message = "Name cannot be null")
	@Size(min=2, max=30)
	@NotEmpty(message = "Name cannot be empty")
	private String name;
	
	@NotNull(message = "Age cannot be null")
	@Size(min=2, max=5)
	@NotEmpty(message = "Age cannot be empty")
	private String age;
	
	@Email(message = "Email format")
	private String email;
	
	
	private String gender;
	
	@NotNull(message = "Name cannot be null")
	private String birthday;
	
	private String phone;
	
	@Valid
	private AddressDto address;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public AddressDto getAddress() {
		return address;
	}

	public void setAddress(AddressDto address) {
		this.address = address;
	}
	
	
	

}
