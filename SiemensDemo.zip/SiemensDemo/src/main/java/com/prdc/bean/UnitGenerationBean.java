package com.prdc.bean;

import java.util.Calendar;
import java.util.Date;

import com.prdc.util.DateUtil;

public class UnitGenerationBean {
	
	private String generatorType;
	private String plantId;
	private String unitId;
	private String value;
	private Date dateTime;
	private String sDateTime;
	public String getGeneratorType() {
		return generatorType;
	}
	public void setGeneratorType(String generatorType) {
		this.generatorType = generatorType;
	}
	public String getPlantId() {
		return plantId;
	}
	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}
	public String getUnitId() {
		return unitId;
	}
	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public String getsDateTime() {
		return sDateTime;
	}
	public void setsDateTime(String sDateTime) {
		this.sDateTime = sDateTime;
	}
	@Override
	public String toString() {
		return "UnitGenerationBean [generatorType=" + generatorType + ", plantId=" + plantId + ", unitId=" + unitId
				+ ", value=" + value + ", dateTime=" + dateTime + ", sDateTime=" + sDateTime + "]";
	}
	

}
