package com.prdc.bean;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

//import org.hibernate.validator.constraints.NotEmpty;


public class AddressDto {
	
	@NotNull(message = "city coonot be empty")
	@Size(min=2, max=30)
//	@NotEmpty(message = "city coonot be null")
	private String city;
	
	
	@NotNull(message = "state coonot be empty")
	@Size(min=2, max=30)
//	@NotEmpty(message = "state coonot be null")
	private String state;
	
	
	@NotNull(message = "street coonot be empty")
//	@NotEmpty(message = "street coonot be null")
	private String street;


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getStreet() {
		return street;
	}


	public void setStreet(String street) {
		this.street = street;
	}

	
	
}
