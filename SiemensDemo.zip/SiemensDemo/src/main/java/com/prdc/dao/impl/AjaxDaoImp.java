package com.prdc.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.prdc.bean.DayAhedReserveBean;
import com.prdc.bean.UnitGenerationBean;
import com.prdc.dao.AjaxDao;
import com.prdc.util.DateUtil;

@Component
public class AjaxDaoImp implements AjaxDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public DayAhedReserveBean chechDayAhedReserveData(DayAhedReserveBean bean) {
		String selectQuery="SELECT IREFID_CONTRACT, TBLOCK_DATE_TIME, FINTERNAL_ENERGY, FINTERNAL_RESERVE, FEXTERNAL_ENERGY, FEXTERNAL_RESERVE FROM ITES_DAY_AHEAD_ENERGY_RESERVE WHERE IREFID_CONTRACT = "+bean.getContractId()+" AND TBLOCK_DATE_TIME = '"+bean.getBlockDateTime()+"'";
		try {
			List<DayAhedReserveBean> count=jdbcTemplate.query(selectQuery, new RowMapper<DayAhedReserveBean>() {
	
				public DayAhedReserveBean mapRow(ResultSet rs, int rowNum) throws SQLException {
					// TODO Auto-generated method stub
					DayAhedReserveBean bean = new DayAhedReserveBean();
					bean.setBlockDateTime(DateUtil.convertStringToDate(rs.getString("TBLOCK_DATE_TIME"), "yyyy-MM-dd HH:mm"));
					bean.setContractId(rs.getString("IREFID_CONTRACT"));
					bean.setInternalEnergyInput(rs.getString("FINTERNAL_ENERGY"));
					bean.setInternalReserveInput(rs.getString("FINTERNAL_RESERVE"));
					bean.setExternalEnergyInput(rs.getString("FEXTERNAL_ENERGY"));
					bean.setExternalReserveInput(rs.getString("FEXTERNAL_RESERVE"));
					return bean;
				}
			});
			if(count!=null && count.size() > 0){
				return count.get(0);
			}
			else {
				return null;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			ex.getLocalizedMessage();
			return null;	
		}
	}

	@Override
	public String insertUpdateAllDayAhedReserveData(ArrayList<String> sqlQueryList) {
		String responce = "";
		try {
			int[] rowCount = jdbcTemplate.batchUpdate(sqlQueryList.toArray(new String[sqlQueryList.size()]));
			responce = "success";
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			responce = "exception";
		}
		return responce;
	}

	@Override
	public Map<String, DayAhedReserveBean> getAllReserveData() {
		// TODO Auto-generated method stub
		Map<String, DayAhedReserveBean> map=new HashMap<>();
		String selectQuery="SELECT IREFID_CONTRACT, TBLOCK_DATE_TIME, FINTERNAL_ENERGY, FINTERNAL_RESERVE, FEXTERNAL_ENERGY, FEXTERNAL_RESERVE ,FTRANSACTION_VALUE FROM ITES_DAY_AHEAD_ENERGY_RESERVE";
		try {
			List<DayAhedReserveBean> listData=jdbcTemplate.query(selectQuery, new RowMapper<DayAhedReserveBean>() {
	
				public DayAhedReserveBean mapRow(ResultSet rs, int rowNum) throws SQLException {
					// TODO Auto-generated method stub
					DayAhedReserveBean bean = new DayAhedReserveBean();
//					bean.setBlockDateTime(rs.getDate("TBLOCK_DATE_TIME"));
					bean.setBlockDateTime(DateUtil.convertStringToDate(rs.getString("TBLOCK_DATE_TIME"), "yyyy-MM-dd HH:mm"));
					bean.setContractId(rs.getString("IREFID_CONTRACT"));
					bean.setInternalEnergyInput(rs.getString("FINTERNAL_ENERGY"));
					bean.setInternalReserveInput(rs.getString("FINTERNAL_RESERVE"));
					bean.setExternalEnergyInput(rs.getString("FEXTERNAL_ENERGY"));
					bean.setExternalReserveInput(rs.getString("FEXTERNAL_RESERVE"));
					bean.setTransactionValue(rs.getString("FTRANSACTION_VALUE"));
					return bean;
				}
			});
			for(DayAhedReserveBean list:listData) {
				if(map.get(list.getContractId()+" "+list.getBlockDateTime())==null) {
					map.put(list.getContractId()+" "+list.getBlockDateTime(), list);
				}
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return map;
	}
	
	@Override
	public Map<String, UnitGenerationBean> getAllUnitGeneration() {
		// TODO Auto-generated method stub
		Map<String, UnitGenerationBean> map=new HashMap<>();
		String query="SELECT TBLOCK_DATE_TIME,IGENERATOR_TYPE,IREFID_PLANT,IREFID_UNIT,FUNIT_MW_GENERATION FROM ITES_DAY_AHEAD_UNIT_GENERATION";
		List<UnitGenerationBean> dataList=jdbcTemplate.query(query, new RowMapper<UnitGenerationBean>() {
			
			@Override
			public UnitGenerationBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				UnitGenerationBean ug=new UnitGenerationBean();
				ug.setsDateTime(rs.getString("TBLOCK_DATE_TIME"));
				ug.setGeneratorType(rs.getString("IGENERATOR_TYPE"));
				ug.setPlantId(rs.getString("IREFID_PLANT"));
				ug.setUnitId(rs.getString("IREFID_UNIT"));
				ug.setValue(rs.getString("FUNIT_MW_GENERATION"));
				return ug;
			}
		});
		for(UnitGenerationBean list:dataList) {
			if(map.get(list.getGeneratorType()+" "+list.getPlantId()+" "+list.getUnitId()+" "+list.getsDateTime())==null) {
				map.put(list.getGeneratorType()+" "+list.getPlantId()+" "+list.getUnitId()+" "+list.getsDateTime(), list);
			}
		}
		return map;
	}


	@Override
	public Map<String, List<DayAhedReserveBean>> getAllReserveData(Date time) {
		Map<String, List<DayAhedReserveBean>> map=new HashMap<>();
//		String selectQuery="SELECT IREFID_CONTRACT, TBLOCK_DATE_TIME, FINTERNAL_ENERGY, FINTERNAL_RESERVE, FEXTERNAL_ENERGY, FEXTERNAL_RESERVE FROM ITES_DAY_AHEAD_ENERGY_RESERVE WHERE date(TBLOCK_DATE_TIME) = '"+DateUtil.convertDateToString(time, "yyyy-MM-dd")+"'";
		String selectQuery="SELECT RES.IREFID_CONTRACT," + 
				"CASE WHEN " + 
				"	SEL.SCOUNTRY=BUY.SCOUNTRY THEN " + 
				"		CASE WHEN CON.ICONTRACT_TYPE = 1 THEN FINTERNAL_ENERGY ELSE FINTERNAL_RESERVE END " + 
				"	ELSE " + 
				"		CASE WHEN CON.ICONTRACT_TYPE = 1 THEN FEXTERNAL_ENERGY ELSE FEXTERNAL_RESERVE END " + 
				" END AS OUTPUT_VAL ," + 
				" CASE WHEN " + 
				"	SEL.SCOUNTRY=BUY.SCOUNTRY THEN " + 
				"		CASE WHEN CON.ICONTRACT_TYPE = 1 THEN 'I E' ELSE 'I A' END" + 
				"	ELSE " + 
				"		CASE WHEN CON.ICONTRACT_TYPE = 1 THEN 'E E' ELSE 'E A' END " + 
				" END AS STATUS_VAL"+
				" FROM ITES_DAY_AHEAD_ENERGY_RESERVE RES JOIN ITES_CONTRACT_DETAILS CON ON RES.IREFID_CONTRACT = CON.ICONTRACT_ID " + 
				" JOIN ITES_COMPANY_DETAILS BUY ON CON.IREFID_BUYER_COMPANY = BUY.ICOMPANY_ID JOIN ITES_COMPANY_DETAILS SEL ON CON.IREFID_SELLER_COMPANY = SEL.ICOMPANY_ID ";
		try {
			List<DayAhedReserveBean> listData=jdbcTemplate.query(selectQuery, new RowMapper<DayAhedReserveBean>() {
	
				public DayAhedReserveBean mapRow(ResultSet rs, int rowNum) throws SQLException {
					// TODO Auto-generated method stub
					DayAhedReserveBean bean = new DayAhedReserveBean();
//					bean.setBlockDateTime(rs.getDate("TBLOCK_DATE_TIME"));
//					bean.setBlockDateTime(DateUtil.convertStringToDate(rs.getString("TBLOCK_DATE_TIME"), "yyyy-MM-dd HH:mm"));
					bean.setContractId(rs.getString("IREFID_CONTRACT"));
					bean.setOutputValue(rs.getString("OUTPUT_VAL"));
					bean.setStatusValue(rs.getString("STATUS_VAL"));
//					bean.setInternalEnergyInput(rs.getString("FINTERNAL_ENERGY"));
//					bean.setInternalReserveInput(rs.getString("FINTERNAL_RESERVE"));
//					bean.setExternalEnergyInput(rs.getString("FEXTERNAL_ENERGY"));
//					bean.setExternalReserveInput(rs.getString("FEXTERNAL_RESERVE"));
					return bean;
				}
			});
			for(DayAhedReserveBean list:listData) {
				if(map.get(list.getContractId())==null) {
					List<DayAhedReserveBean> value=new ArrayList<>();
					value.add(list);
					map.put(list.getContractId(), value);
				}else {
					map.get(list.getContractId()).add(list);
				}
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return map;
	}
}
