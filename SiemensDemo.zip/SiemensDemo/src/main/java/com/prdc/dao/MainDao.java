package com.prdc.dao;

import java.util.List;

import com.prdc.bean.CompanyInfoBean;
/**
 * @author Tilak R
 
 * 
 */
public interface MainDao {

	List<String> getValues();

	

}
