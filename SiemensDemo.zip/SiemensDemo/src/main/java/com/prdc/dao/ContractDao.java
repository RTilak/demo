package com.prdc.dao;

import java.util.List;

import com.prdc.bean.ContractBean;
/**
 * @author Tilak R
 
 * 
 */
public interface ContractDao {

	String insertContract(ContractBean cb);
	
	List<ContractBean> getContractList();

	List<ContractBean> getContractInfoDetails(String id);

	String updateContract(ContractBean cb);

}
