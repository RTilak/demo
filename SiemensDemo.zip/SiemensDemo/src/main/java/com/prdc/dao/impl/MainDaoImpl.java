package com.prdc.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.prdc.bean.CompanyInfoBean;
import com.prdc.dao.MainDao;
/**
 * @author Tilak R
 
 * 
 */

@Component
public class MainDaoImpl implements MainDao{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<String> getValues() {
		// TODO Auto-generated method stub
		List<String> list;
		String sqlLevelDetails = "Select fconfigvalue from config_base_network";
		
		list=jdbcTemplate.query(sqlLevelDetails, new RowMapper<String>() {

			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return rs.getString("fconfigvalue");
			}
			
		});
		return list;
	}

	
		
}
