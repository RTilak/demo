package com.prdc.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.prdc.bean.ContractBean;
import com.prdc.dao.ContractDao;
import com.prdc.util.DateUtil;
/**
 * @author Tilak R
 
 * 
 */
@Component
public class ContractDaoImpl implements ContractDao{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public String insertContract(ContractBean cb) {
		// TODO Auto-generated method stub
		String query="INSERT INTO ITES_CONTRACT_DETAILS (ICONTRACT_ID,SCONTRACT_NO,ICONTRACT_TYPE,ICONTRACT_SUB_TYPE,TSTART_DATE_TIME,TEND_DATE_TIME,IREFID_BUYER_COMPANY"
				+ ",IREFID_SELLER_COMPANY,IREFID_TRADER_COMPANY,SCURRENCY_UNIT,FCOST_CURRENCY_PER_UNIT,FPENALTY_CURRENCY_PER_UNIT,ITIME_INTERVAL,FENERGY_RAMPING_MW, "
//				+ "IENERGY_SCH_INTERVAL,"
//				+ "FANCILIARY_MAX_RESERVE_MW, "
				+ "IANCILIARY_STARTUP_TIME,FANCILIARY_STARTUP_COST)"
				+ " VALUES (nextval('SEQ_ITES_CONTRACT_DETAILS'),'"+cb.getContractNo()+"',"+cb.getContractType()+","+cb.getContractSubType()+",'"+cb.getStartDateTime()+"'"
						+ ",'"+cb.getEndDateTime()+"',"+cb.getBuyerId()+","+cb.getSellerId()+","+cb.getTraderId()+",'"+cb.getCurrencyUnit()+"',"+cb.getCostCurrencyPerUnit()+""
						+ ","+cb.getPenaltyCurrencyPerUnit()+","+cb.getTimeInterval()+","+(cb.getEnergyRampingMW().equalsIgnoreCase("")?null:cb.getEnergyRampingMW())+","+
//						cb.getEnergySchInterval()+","+
//						cb.getAnciliaryMaxReserveMW()+","+
						cb.getAnciliaryStartUpTime()+","+cb.getAnciliaryStartUpCost()+")";
		try {
			jdbcTemplate.execute(query);
			return "success";
		}catch(Exception e) {
			e.printStackTrace();
			return "error";
		}
	}
	
	@Override
	public List<ContractBean> getContractList() {
		// TODO Auto-generated method stub
		String query="SELECT CND.ICONTRACT_ID, CND.SCONTRACT_NO, CND.ICONTRACT_TYPE, CND.ICONTRACT_SUB_TYPE, CND.TSTART_DATE_TIME, CND.TEND_DATE_TIME, CND.IREFID_BUYER_COMPANY, "
				+ " CND.IREFID_SELLER_COMPANY, CND.IREFID_TRADER_COMPANY, CND.SCURRENCY_UNIT, CND.FCOST_CURRENCY_PER_UNIT, CND.FPENALTY_CURRENCY_PER_UNIT, CND.ITIME_INTERVAL, "
				+ "CND.FENERGY_RAMPING_MW, CPD1.SCOMPANY_NAME AS SELLER, CPD2.SCOMPANY_NAME AS BUYER, CPD3.SCOMPANY_NAME AS TRADER ,"
//				+ "IENERGY_SCH_INTERVAL,"
//				+ "FANCILIARY_MAX_RESERVE_MW,"
				+ "IANCILIARY_STARTUP_TIME,FANCILIARY_STARTUP_COST"
				+ " FROM ITES_CONTRACT_DETAILS CND JOIN ITES_COMPANY_DETAILS CPD1 ON CPD1.ICOMPANY_ID = CND.IREFID_SELLER_COMPANY " + 
				" JOIN ITES_COMPANY_DETAILS CPD2 ON CPD2.ICOMPANY_ID = CND.IREFID_BUYER_COMPANY " + 
				" JOIN ITES_COMPANY_DETAILS CPD3 ON CPD3.ICOMPANY_ID = CND.IREFID_TRADER_COMPANY";
		return jdbcTemplate.query(query, new RowMapper<ContractBean>() {

			@Override
			public ContractBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				ContractBean cb=new ContractBean();
				cb.setSellerId(rs.getString("IREFID_SELLER_COMPANY"));
				cb.setBuyerId(rs.getString("IREFID_BUYER_COMPANY"));
				cb.setTraderId(rs.getString("IREFID_TRADER_COMPANY"));
				cb.setContractNo(rs.getString("SCONTRACT_NO"));
				cb.setContractType(rs.getString("ICONTRACT_TYPE"));
				cb.setContractSubType(rs.getString("ICONTRACT_SUB_TYPE"));
				cb.setCostCurrencyPerUnit(rs.getString("FCOST_CURRENCY_PER_UNIT"));
				cb.setCurrencyUnit(rs.getString("SCURRENCY_UNIT"));
//				cb.setsEndDateTime(rs.getString("TEND_DATE_TIME"));
				cb.setsEndDateTime(DateUtil.convertDateToString(DateUtil.convertStringToDate(rs.getString("TEND_DATE_TIME"), "yyyy-MM-dd hh:mm:ss"), "dd-MM-yyyy hh:mm a"));
				// cb.setFrampingCapacity(rs.getString("FRAMPING_CAPACITY"));
				cb.setEnergyRampingMW(rs.getString("FENERGY_RAMPING_MW"));
				cb.setPenaltyCurrencyPerUnit(rs.getString("FPENALTY_CURRENCY_PER_UNIT"));
				cb.setsStartDateTime(DateUtil.convertDateToString(DateUtil.convertStringToDate(rs.getString("TSTART_DATE_TIME"), "yyyy-MM-dd hh:mm:ss"), "dd-MM-yyyy hh:mm a"));
				cb.setTimeInterval(rs.getString("ITIME_INTERVAL"));
				cb.setId(rs.getString("ICONTRACT_ID"));
				cb.setSellerName(rs.getString("SELLER"));
				cb.setBuyerName(rs.getString("BUYER"));
				cb.setTraderName(rs.getString("TRADER"));
//				cb.setAnciliaryMaxReserveMW(rs.getString("FANCILIARY_MAX_RESERVE_MW"));
//				cb.setEnergySchInterval(rs.getString("IENERGY_SCH_INTERVAL"));
				cb.setAnciliaryStartUpCost(rs.getString("FANCILIARY_STARTUP_COST"));
				cb.setAnciliaryStartUpTime(rs.getString("IANCILIARY_STARTUP_TIME"));
				return cb;
			}
		});
	}

	@Override
	public List<ContractBean> getContractInfoDetails(String id) {
		// TODO Auto-generated method stub
		String query="SELECT ICONTRACT_ID, SCONTRACT_NO, ICONTRACT_TYPE, ICONTRACT_SUB_TYPE, TSTART_DATE_TIME, TEND_DATE_TIME, IREFID_BUYER_COMPANY, "
				+ " IREFID_SELLER_COMPANY, IREFID_TRADER_COMPANY, SCURRENCY_UNIT, FCOST_CURRENCY_PER_UNIT, FPENALTY_CURRENCY_PER_UNIT, ITIME_INTERVAL, FENERGY_RAMPING_MW, "
//				+ " IENERGY_SCH_INTERVAL,"
//				+ "FANCILIARY_MAX_RESERVE_MW, "
				+ "IANCILIARY_STARTUP_TIME,FANCILIARY_STARTUP_COST FROM "
				+ " ITES_CONTRACT_DETAILS WHERE ICONTRACT_ID = " + id;
		return jdbcTemplate.query(query, new RowMapper<ContractBean>() {

			@Override
			public ContractBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				ContractBean cb=new ContractBean();
				cb.setSellerId(rs.getString("IREFID_SELLER_COMPANY"));
				cb.setBuyerId(rs.getString("IREFID_BUYER_COMPANY"));
				cb.setTraderId(rs.getString("IREFID_TRADER_COMPANY"));
				cb.setContractNo(rs.getString("SCONTRACT_NO"));
				cb.setContractType(rs.getString("ICONTRACT_TYPE"));
				cb.setContractSubType(rs.getString("ICONTRACT_SUB_TYPE"));
				cb.setCostCurrencyPerUnit(rs.getString("FCOST_CURRENCY_PER_UNIT"));
				cb.setCurrencyUnit(rs.getString("SCURRENCY_UNIT"));
//				cb.setsEndDateTime(rs.getString("TEND_DATE_TIME"));
				cb.setsEndDateTime(DateUtil.convertDateToString(DateUtil.convertStringToDate(rs.getString("TEND_DATE_TIME"), "yyyy-MM-dd hh:mm:ss"), "dd-MM-yyyy hh:mm a"));
				// cb.setFrampingCapacity(rs.getString("FRAMPING_CAPACITY"));
				cb.setEnergyRampingMW(rs.getString("FENERGY_RAMPING_MW"));
				cb.setPenaltyCurrencyPerUnit(rs.getString("FPENALTY_CURRENCY_PER_UNIT"));
//				cb.setsStartDateTime(rs.getString("TSTART_DATE_TIME"));
				cb.setsStartDateTime(DateUtil.convertDateToString(DateUtil.convertStringToDate(rs.getString("TSTART_DATE_TIME"), "yyyy-MM-dd hh:mm:ss"), "dd-MM-yyyy hh:mm a"));
				cb.setTimeInterval(rs.getString("ITIME_INTERVAL"));
				cb.setId(rs.getString("ICONTRACT_ID"));
//				cb.setAnciliaryMaxReserveMW(rs.getString("FANCILIARY_MAX_RESERVE_MW"));
//				cb.setEnergySchInterval(rs.getString("IENERGY_SCH_INTERVAL"));
				cb.setAnciliaryStartUpCost(rs.getString("FANCILIARY_STARTUP_COST"));
				cb.setAnciliaryStartUpTime(rs.getString("IANCILIARY_STARTUP_TIME"));
				return cb;
			}
		});
	}

	@Override
	public String updateContract(ContractBean cb) {
		// TODO Auto-generated method stub
		String query="UPDATE ITES_CONTRACT_DETAILS  SET SCONTRACT_NO = '"+cb.getContractNo()+"', ICONTRACT_TYPE = "+cb.getContractType()+", ICONTRACT_SUB_TYPE = "+cb.getContractSubType()+", "
				+ " TSTART_DATE_TIME = '"+cb.getStartDateTime()+"',TEND_DATE_TIME = '"+cb.getEndDateTime()+"',IREFID_BUYER_COMPANY = "+cb.getBuyerId()+", "
				+ " IREFID_SELLER_COMPANY = "+cb.getSellerId()+", IREFID_TRADER_COMPANY = "+cb.getTraderId()+", SCURRENCY_UNIT = '"+cb.getCurrencyUnit()+"', "
				+ " FCOST_CURRENCY_PER_UNIT = "+cb.getCostCurrencyPerUnit()+", FPENALTY_CURRENCY_PER_UNIT = "+cb.getPenaltyCurrencyPerUnit()+",ITIME_INTERVAL = "+cb.getTimeInterval()+", "
				+ " FENERGY_RAMPING_MW = "+cb.getEnergyRampingMW()+
				//",IENERGY_SCH_INTERVAL= "+cb.getEnergySchInterval()+" "
				//", FANCILIARY_MAX_RESERVE_MW="+cb.getAnciliaryMaxReserveMW() +
				"  ,IANCILIARY_STARTUP_TIME = "+cb.getAnciliaryStartUpTime()+" , FANCILIARY_STARTUP_COST = "+cb.getAnciliaryStartUpCost()+" WHERE ICONTRACT_ID = "+ cb.getId();
		try {
			jdbcTemplate.execute(query);
			return "success";
		}catch(Exception e) {
			e.printStackTrace();
			return "error";
		}
	}

}
