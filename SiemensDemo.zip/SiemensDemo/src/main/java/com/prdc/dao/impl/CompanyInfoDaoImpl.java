package com.prdc.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.prdc.bean.CompanyInfoBean;
import com.prdc.dao.CompanyInfoDao;
import com.prdc.enums.CompanyType;
/**
 * @author Tilak R
 
 * 
 */
@Component
public class CompanyInfoDaoImpl implements CompanyInfoDao{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	@Override
	public String saveCompanyInfo(CompanyInfoBean companyInfoBean) {
		// TODO Auto-generated method stub
		String selectQuery="SELECT count(ICOMPANY_ID) AS count_cname FROM ITES_COMPANY_DETAILS WHERE ICOMPANY_TYPE = "+companyInfoBean.getCompanyType().getIdentifier() +
				" AND SCOMPANY_NAME = '"+companyInfoBean.getName()+"' AND SCOUNTRY = '"+companyInfoBean.getCountry()+"' AND SSTATE = '"+companyInfoBean.getState()+"'";
		try {
			List<String> count=jdbcTemplate.query(selectQuery, new RowMapper<String>() {
	
				public String mapRow(ResultSet rs, int rowNum) throws SQLException {
					// TODO Auto-generated method stub
					return rs.getString("count_cname");
				}
			});
			if(count!=null && Integer.valueOf(count.get(0))>0){
				return "exist";
			}
			
			
			else {
				String 	insertQuery="INSERT INTO ITES_COMPANY_DETAILS (ICOMPANY_ID,ICOMPANY_TYPE,SCOMPANY_NAME,SCOUNTRY,SSTATE,SADDRESS,SEMAIL_ID,SPHONE_NO,FMAX_SELL_CAPACITY_MW,FMAX_BUY_CAPACITY_MW) "
						+ "VALUES(nextval('SEQ_ITES_COMPANY_DETAILS'),"+companyInfoBean.getCompanyType().getIdentifier()+",'"+companyInfoBean.getName()+"','"+companyInfoBean.getCountry()+"','"+companyInfoBean.getState()+"','"+companyInfoBean.getAddress()+"','"+companyInfoBean.getEmail()+"','"+companyInfoBean.getPhoneNo()+"',"+companyInfoBean.getMaxSellCapacity()+","+companyInfoBean.getMaxBuyCapacity()+")";
//				System.out.println("------"+insertQuery);
				jdbcTemplate.execute(insertQuery);
				return "success";
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			ex.getLocalizedMessage();
			return "error";	
		}
	}

	@Override
	public List<CompanyInfoBean> getCompanyInfoList() {
		// TODO Auto-generated method stub
		String query="SELECT ICOMPANY_ID,ICOMPANY_TYPE,SCOMPANY_NAME,SCOUNTRY,SSTATE,SADDRESS,SEMAIL_ID,SPHONE_NO,FMAX_SELL_CAPACITY_MW,FMAX_BUY_CAPACITY_MW, FMAX_SELL_RESERVE_MW, FMAX_BUY_RESERVE_MW FROM ITES_COMPANY_DETAILS";
		return jdbcTemplate.query(query, new RowMapper<CompanyInfoBean>() {

			@Override
			public CompanyInfoBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompanyInfoBean cb=new CompanyInfoBean();
				cb.setCompanyType(CompanyType.getEnum(rs.getString("ICOMPANY_TYPE")));
				cb.setAddress(rs.getString("SADDRESS"));
				cb.setCountry(rs.getString("SCOUNTRY"));
				cb.setEmail(rs.getString("SEMAIL_ID"));
				cb.setMaxBuyCapacity(rs.getDouble("FMAX_BUY_CAPACITY_MW"));
				cb.setMaxSellCapacity(rs.getDouble("FMAX_SELL_CAPACITY_MW"));
				cb.setMaxBuyReserve(rs.getDouble("FMAX_SELL_RESERVE_MW"));
				cb.setMaxSellReserve(rs.getDouble("FMAX_BUY_RESERVE_MW"));
				cb.setName(rs.getString("SCOMPANY_NAME"));
				cb.setState(rs.getString("SSTATE"));
				cb.setPhoneNo(rs.getString("SPHONE_NO"));
				cb.setId(rs.getString("ICOMPANY_ID"));
				return cb;
			}
			
		});
	}

	@Override
	public List<CompanyInfoBean> getCompanyInfoDetails(String id) {
		// TODO Auto-generated method stub
		String query="SELECT ICOMPANY_ID,ICOMPANY_TYPE,SCOMPANY_NAME,SCOUNTRY,SSTATE,SADDRESS,SEMAIL_ID,SPHONE_NO,FMAX_SELL_CAPACITY_MW,FMAX_BUY_CAPACITY_MW, FMAX_SELL_RESERVE_MW, FMAX_BUY_RESERVE_MW FROM ITES_COMPANY_DETAILS WHERE ICOMPANY_ID = "+id;
		return jdbcTemplate.query(query, new RowMapper<CompanyInfoBean>() {

			@Override
			public CompanyInfoBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompanyInfoBean cb=new CompanyInfoBean();
				cb.setCompanyType(CompanyType.getEnum(rs.getString("ICOMPANY_TYPE")));
				cb.setAddress(rs.getString("SADDRESS"));
				cb.setCountry(rs.getString("SCOUNTRY"));
				cb.setEmail(rs.getString("SEMAIL_ID"));
				cb.setMaxBuyCapacity(rs.getDouble("FMAX_BUY_CAPACITY_MW"));
				cb.setMaxSellCapacity(rs.getDouble("FMAX_SELL_CAPACITY_MW"));
				cb.setMaxBuyReserve(rs.getDouble("FMAX_SELL_RESERVE_MW"));
				cb.setMaxSellReserve(rs.getDouble("FMAX_BUY_RESERVE_MW"));
				cb.setName(rs.getString("SCOMPANY_NAME"));
				cb.setState(rs.getString("SSTATE"));
				cb.setPhoneNo(rs.getString("SPHONE_NO"));
				cb.setId(rs.getString("ICOMPANY_ID"));
				return cb;
			}
			
		});
	}

	@Override
	public String updateCompanyInfoDetails(CompanyInfoBean companyInfoBean) {
		// TODO Auto-generated method stub
		String query="UPDATE ITES_COMPANY_DETAILS SET ICOMPANY_TYPE = "+companyInfoBean.getCompanyType().getIdentifier()+",SCOMPANY_NAME = '"+companyInfoBean.getName()+"' ,SSTATE = '"+companyInfoBean.getState()+"'"
				+ ",SCOUNTRY = '"+companyInfoBean.getCountry()+"',SADDRESS = '"+companyInfoBean.getAddress()+"'"
						+ ",SEMAIL_ID = '"+companyInfoBean.getEmail()+"',SPHONE_NO = '"+companyInfoBean.getPhoneNo()+"'"
								+ ",FMAX_SELL_CAPACITY_MW = "+companyInfoBean.getMaxSellCapacity()+",FMAX_BUY_CAPACITY_MW = "+companyInfoBean.getMaxBuyCapacity()+" WHERE ICOMPANY_ID = "+companyInfoBean.getId();
//		System.out.println("query---"+query);
		try {
			jdbcTemplate.execute(query);
			return "success";
		}catch(Exception e){
			e.printStackTrace();
			return "error";
		}
	}

	@Override
	public List<CompanyInfoBean> getSellerCompany() {
		String query="SELECT ICOMPANY_ID,ICOMPANY_TYPE,SCOMPANY_NAME,SCOUNTRY,SSTATE,SADDRESS,SEMAIL_ID,SPHONE_NO,FMAX_SELL_CAPACITY_MW,FMAX_BUY_CAPACITY_MW FROM ITES_COMPANY_DETAILS WHERE ICOMPANY_TYPE = 1 or ICOMPANY_TYPE = 4";
		return jdbcTemplate.query(query, new RowMapper<CompanyInfoBean>() {

			@Override
			public CompanyInfoBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompanyInfoBean cb=new CompanyInfoBean();
				cb.setCompanyType(CompanyType.getEnum(rs.getString("ICOMPANY_TYPE")));
				cb.setAddress(rs.getString("SADDRESS"));
				cb.setCountry(rs.getString("SCOUNTRY"));
				cb.setEmail(rs.getString("SEMAIL_ID"));
				cb.setMaxBuyCapacity(rs.getDouble("FMAX_BUY_CAPACITY_MW"));
				cb.setMaxSellCapacity(rs.getDouble("FMAX_SELL_CAPACITY_MW"));
				cb.setName(rs.getString("SCOMPANY_NAME"));
				cb.setState(rs.getString("SSTATE"));
				cb.setPhoneNo(rs.getString("SPHONE_NO"));
				cb.setId(rs.getString("ICOMPANY_ID"));
				return cb;
			}
			
		});
	}

	@Override
	public List<CompanyInfoBean> getBuyerCompany() {
		String query="SELECT ICOMPANY_ID,ICOMPANY_TYPE,SCOMPANY_NAME,SCOUNTRY,SSTATE,SADDRESS,SEMAIL_ID,SPHONE_NO,FMAX_SELL_CAPACITY_MW,FMAX_BUY_CAPACITY_MW FROM ITES_COMPANY_DETAILS WHERE ICOMPANY_TYPE = 2 or ICOMPANY_TYPE = 4";
		return jdbcTemplate.query(query, new RowMapper<CompanyInfoBean>() {

			@Override
			public CompanyInfoBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompanyInfoBean cb=new CompanyInfoBean();
				cb.setCompanyType(CompanyType.getEnum(rs.getString("ICOMPANY_TYPE")));
				cb.setAddress(rs.getString("SADDRESS"));
				cb.setCountry(rs.getString("SCOUNTRY"));
				cb.setEmail(rs.getString("SEMAIL_ID"));
				cb.setMaxBuyCapacity(rs.getDouble("FMAX_BUY_CAPACITY_MW"));
				cb.setMaxSellCapacity(rs.getDouble("FMAX_SELL_CAPACITY_MW"));
				cb.setName(rs.getString("SCOMPANY_NAME"));
				cb.setState(rs.getString("SSTATE"));
				cb.setPhoneNo(rs.getString("SPHONE_NO"));
				cb.setId(rs.getString("ICOMPANY_ID"));
				return cb;
			}
			
		});
	}

	@Override
	public List<CompanyInfoBean> getTraderCompany() {
		String query="SELECT ICOMPANY_ID,ICOMPANY_TYPE,SCOMPANY_NAME,SCOUNTRY,SSTATE,SADDRESS,SEMAIL_ID,SPHONE_NO,FMAX_SELL_CAPACITY_MW,FMAX_BUY_CAPACITY_MW FROM ITES_COMPANY_DETAILS WHERE ICOMPANY_TYPE = 3 or ICOMPANY_TYPE = 4";
		return jdbcTemplate.query(query, new RowMapper<CompanyInfoBean>() {

			@Override
			public CompanyInfoBean mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompanyInfoBean cb=new CompanyInfoBean();
				cb.setCompanyType(CompanyType.getEnum(rs.getString("ICOMPANY_TYPE")));
				cb.setAddress(rs.getString("SADDRESS"));
				cb.setCountry(rs.getString("SCOUNTRY"));
				cb.setEmail(rs.getString("SEMAIL_ID"));
				cb.setMaxBuyCapacity(rs.getDouble("FMAX_BUY_CAPACITY_MW"));
				cb.setMaxSellCapacity(rs.getDouble("FMAX_SELL_CAPACITY_MW"));
				cb.setName(rs.getString("SCOMPANY_NAME"));
				cb.setState(rs.getString("SSTATE"));
				cb.setPhoneNo(rs.getString("SPHONE_NO"));
				cb.setId(rs.getString("ICOMPANY_ID"));
				return cb;
			}
			
		});
	}

}
