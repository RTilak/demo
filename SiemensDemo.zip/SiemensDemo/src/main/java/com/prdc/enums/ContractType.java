package com.prdc.enums;
/**
 * @author Tilak R
 
 * 
 */
public enum ContractType {
	
	ENERGY("1","Energy"),
	ANCILIARY("2","Anciliary");
	
	private String name;
	private String identifier;
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getIdentifier() {
		return identifier;
	}


	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}


	private ContractType(String name, String identifier) {
		this.name = name;
		this.identifier = identifier;
	}
	
	public static ContractType getEnum(String name) {
		if(name == null)
            throw new IllegalArgumentException();
        for(ContractType v : values())
            if(name.equalsIgnoreCase(v.getName())) return v;
        for(ContractType v : values())
            if(name.equalsIgnoreCase(v.getIdentifier())) return v;
        throw new IllegalArgumentException(); 
	}
}
