package com.prdc.enums;
/**
 * @author Tilak R
 
 * 
 */
public enum AnciliaryTypeEnum {
	
	PRIMARY("1","Primary"),
	SECONDARY("2","Secondary"),
	TERITARY("3","Tertiary"),
	SPINNING("4","Spinning"),
	NONSPINNING("5","Non-Spinning");
	
	private String name;
	private String identifier;
	
	
	private AnciliaryTypeEnum(String identifier , String name) {
		this.name = name;
		this.identifier = identifier;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getIdentifier() {
		return identifier;
	}


	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	
	public static AnciliaryTypeEnum getEnum(String name) {
		if(name == null)
            throw new IllegalArgumentException();
        for(AnciliaryTypeEnum v : values())
            if(name.equalsIgnoreCase(v.getName())) return v;
        for(AnciliaryTypeEnum v : values())
            if(name.equalsIgnoreCase(v.getIdentifier())) return v;
        throw new IllegalArgumentException(); 
	}
}
