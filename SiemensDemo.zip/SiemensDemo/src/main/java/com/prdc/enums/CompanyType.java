package com.prdc.enums;
/**
 * @author Tilak R
 
 * 
 */
public enum CompanyType {
	
	SELLER("1","Seller"),
	BUYER("2","Buyer"),
	TRADER("3","Trader"),
	ALL("4","All");
	
	private String identifier;
	private String name;
	
	
	private CompanyType(String identifier, String name) {
		this.identifier = identifier;
		this.name = name;
	}


	public String getIdentifier() {
		return identifier;
	}


	public String getName() {
		return name;
	}

	
 @Override
    public String toString() {
        return this.getName();
    }

    public static CompanyType getEnum(String name) {
        if(name == null)
            throw new IllegalArgumentException();
        for(CompanyType v : values())
            if(name.equalsIgnoreCase(v.getName())) return v;
        for(CompanyType v : values())
            if(name.equalsIgnoreCase(v.getIdentifier())) return v;
        throw new IllegalArgumentException(); 
    }
}
