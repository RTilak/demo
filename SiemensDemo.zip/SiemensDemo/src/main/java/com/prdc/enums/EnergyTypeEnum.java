package com.prdc.enums;
/**
 * @author Tilak R
 
 * 
 */
public enum EnergyTypeEnum {
	SHORT("1","Short Term Open Access"),
	MEDIUM("2","Medium Term Open Access"),
	LONG("3","Long Term Open Access");
	
	private String identifier;
	private String name;
	
	private EnergyTypeEnum(String identifier, String name) {
		this.identifier = identifier;
		this.name = name;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public static EnergyTypeEnum getEnum(String name) {
		if(name == null)
            throw new IllegalArgumentException();
        for(EnergyTypeEnum v : values())
            if(name.equalsIgnoreCase(v.getName())) return v;
        for(EnergyTypeEnum v : values())
            if(name.equalsIgnoreCase(v.getIdentifier())) return v;
        throw new IllegalArgumentException(); 
	}
}
