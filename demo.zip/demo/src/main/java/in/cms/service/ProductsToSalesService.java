package in.cms.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import in.cms.dto.ProductsToSalesDto;
import in.cms.entity.ProductsToSales;

public interface ProductsToSalesService {

	Page<ProductsToSales> findAll(Pageable page);

	ProductsToSales findByProductId(Long productId);

	void save(ProductsToSalesDto dto);

	ProductsToSalesDto findOne(Long id);

}
