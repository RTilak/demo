package in.cms.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import in.cms.dto.ProductPuchasedDto;
import in.cms.entity.ProductPuchased;
import in.cms.entity.Products;
import in.cms.repository.ProductPuchasedRepository;
import in.cms.service.ProductPuchasedService;

@Service
public class ProductPuchasedServiceImpl implements ProductPuchasedService{
	
	@Autowired
	private ProductPuchasedRepository productPuchasedRepository;

	public void save(ProductPuchasedDto dto) {
		// TODO Auto-generated method stub
		ProductPuchased entity=new ProductPuchased();
		entity.setDescription(dto.getDescription());
		entity.setQuantity(dto.getQuantity());
		Products pro=new Products();
		pro.setId(dto.getProductId());
		entity.setProducts(pro);
		entity.setDatePurchased(dto.getDatePurchased());
		if(dto.getId()!=null) {
			entity.setId(dto.getId());
		}
		productPuchasedRepository.save(entity);
		
	}

	public Page<ProductPuchased> findAll(Pageable page) {
		// TODO Auto-generated method stub
		return productPuchasedRepository.findAll(page);
	}

	public ProductPuchased findByProductId(Long productId) {
		// TODO Auto-generated method stub
		Products pro=new Products();
		pro.setId(productId);
		return productPuchasedRepository.findByProducts(pro);
	}

	public ProductPuchasedDto findOne(Long id) {
		// TODO Auto-generated method stub
		ProductPuchased proPur=productPuchasedRepository.findOne(id);
		ProductPuchasedDto dto=new ProductPuchasedDto();
		dto.setDescription(proPur.getDescription());
		dto.setQuantity(proPur.getQuantity());
		dto.setProductId(proPur.getProducts().getId());
		dto.setDatePurchased(proPur.getDatePurchased());
		dto.setId(proPur.getId());
		return dto;
	}

	public void save(ProductPuchased proPur) {
		// TODO Auto-generated method stub
		productPuchasedRepository.save(proPur);
	}
	
	
	

}
