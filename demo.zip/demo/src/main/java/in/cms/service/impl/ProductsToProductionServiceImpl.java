package in.cms.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import in.cms.dto.ProductPuchasedDto;
import in.cms.dto.ProductsToProductionDto;
import in.cms.entity.ProductPuchased;
import in.cms.entity.Products;
import in.cms.entity.ProductsToProduction;
import in.cms.repository.ProductsToProductionRepository;
import in.cms.service.ProductPuchasedService;
import in.cms.service.ProductsToProductionService;

@Service
public class ProductsToProductionServiceImpl implements ProductsToProductionService{
	
	@Autowired
	private ProductsToProductionRepository productsToProductionRepository;
	

	public Page<ProductsToProduction> findAll(Pageable page) {
		// TODO Auto-generated method stub
		return productsToProductionRepository.findAll(page);
	}

	public ProductsToProduction findByProductId(Long productId) {
		// TODO Auto-generated method stub
		Products pro=new Products();
		pro.setId(productId);
		return productsToProductionRepository.findByProducts(pro);
	}

	public void save(ProductsToProductionDto dto) {
		// TODO Auto-generated method stub
		ProductsToProduction entity=new ProductsToProduction();
		entity.setDescription(dto.getDescription());
		entity.setQuantity(dto.getQuantity());
		Products pro=new Products();
		pro.setId(dto.getProductId());
		entity.setProducts(pro);
		if(dto.getId()!=null) {
			entity.setId(dto.getId());
		}
		productsToProductionRepository.save(entity);
	}

	public ProductsToProductionDto findOne(Long id) {
		// TODO Auto-generated method stub
		ProductsToProduction proPur=productsToProductionRepository.findOne(id);
		ProductsToProductionDto dto=new ProductsToProductionDto();
		dto.setDescription(proPur.getDescription());
		dto.setQuantity(proPur.getQuantity());
		dto.setProductId(proPur.getProducts().getId());
		dto.setId(proPur.getId());
		return dto;
	}

	public void save(ProductsToProduction proPur) {
		// TODO Auto-generated method stub
		productsToProductionRepository.save(proPur);
	}

}
