package in.cms.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import in.cms.dto.ProductPuchasedDto;
import in.cms.entity.ProductPuchased;

public interface ProductPuchasedService {

	void save(ProductPuchasedDto dto);

	Page<ProductPuchased> findAll(Pageable page);

	ProductPuchased findByProductId(Long productId);

	ProductPuchasedDto findOne(Long id);

	void save(ProductPuchased proPur);

}
