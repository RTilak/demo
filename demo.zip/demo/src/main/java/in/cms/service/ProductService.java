package in.cms.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import in.cms.entity.Products;

public interface ProductService {

	Page<Products> findAll(Pageable page);

	void save(Products product);

	Products findOne(Long id);

	List<Products> findAll();

}
