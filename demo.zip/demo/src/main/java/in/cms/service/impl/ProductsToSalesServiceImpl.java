package in.cms.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import in.cms.dto.ProductsToProductionDto;
import in.cms.dto.ProductsToSalesDto;
import in.cms.entity.Products;
import in.cms.entity.ProductsToProduction;
import in.cms.entity.ProductsToSales;
import in.cms.repository.ProductsToSalesRepository;
import in.cms.service.ProductsToSalesService;

@Service
public class ProductsToSalesServiceImpl implements ProductsToSalesService{
	
	@Autowired
	private ProductsToSalesRepository productsToSalesRepository;
	
	public Page<ProductsToSales> findAll(Pageable page) {
		// TODO Auto-generated method stub
		return productsToSalesRepository.findAll(page);
	}

	public ProductsToSales findByProductId(Long productId) {
		// TODO Auto-generated method stub
		Products pro=new Products();
		pro.setId(productId);
		return productsToSalesRepository.findByProducts(pro);
	}

	public void save(ProductsToSalesDto dto) {
		// TODO Auto-generated method stub
		ProductsToSales entity=new ProductsToSales();
		entity.setDescription(dto.getDescription());
		entity.setQuantity(dto.getQuantity());
		Products pro=new Products();
		pro.setId(dto.getProductId());
		entity.setProducts(pro);
		if(dto.getId()!=null) {
			entity.setId(dto.getId());
		}
		productsToSalesRepository.save(entity);
	}

	public ProductsToSalesDto findOne(Long id) {
		// TODO Auto-generated method stub
		ProductsToSales proPur=productsToSalesRepository.findOne(id);
		ProductsToSalesDto dto=new ProductsToSalesDto();
		dto.setDescription(proPur.getDescription());
		dto.setQuantity(proPur.getQuantity());
		dto.setProductId(proPur.getProducts().getId());
		dto.setId(proPur.getId());
		return dto;
	}

}
