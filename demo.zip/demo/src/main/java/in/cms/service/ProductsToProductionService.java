package in.cms.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import in.cms.dto.ProductsToProductionDto;
import in.cms.entity.ProductsToProduction;

public interface ProductsToProductionService {

	Page<ProductsToProduction> findAll(Pageable page);

	ProductsToProduction findByProductId(Long productId);

	void save(ProductsToProductionDto dto);

	ProductsToProductionDto findOne(Long id);

	void save(ProductsToProduction proPur);

}
