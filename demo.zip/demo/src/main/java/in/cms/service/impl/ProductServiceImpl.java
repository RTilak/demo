package in.cms.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import in.cms.entity.Products;
import in.cms.repository.ProductRepository;
import in.cms.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductRepository productRepository;

	public Page<Products> findAll(Pageable page) {
		// TODO Auto-generated method stub
		return productRepository.findAll(page);
	}

	public void save(Products product) {
		// TODO Auto-generated method stub
		productRepository.save(product);
	}

	public Products findOne(Long id) {
		// TODO Auto-generated method stub
		return productRepository.findOne(id);
	}

	public List<Products> findAll() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

}
