package in.cms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="products_to_sales")
public class ProductsToSales extends AbstractAuditableEntity{
	
	@Column(name="quantity")
	private Long quantity;
	
	@Column(name="description")
	private String description; 
	
	@JoinColumn(name="product_id",referencedColumnName="id")
	@ManyToOne(fetch=FetchType.EAGER)
	private Products products;

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Products getProducts() {
		return products;
	}

	public void setProducts(Products products) {
		this.products = products;
	}
	
	
}
