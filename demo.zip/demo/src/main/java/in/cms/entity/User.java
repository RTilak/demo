package in.cms.entity;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "users")
public class User extends AbstractAuditableEntity {

	private static final long serialVersionUID = -8331590321678918644L;
	@Column(name = "username", nullable = false)
	private String username;
	@Column(name = "password", nullable = false)
	private String password;
	@Column(name = "change_password")
	private boolean changePassword;
	@Column(name = "active", nullable = false)
	private boolean active = true;
	@OneToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.EAGER,optional = false)
	@JoinColumn(name = "person_id", nullable = false)
	private Person person;
	@ManyToOne(optional = false)
	@JoinColumn(name = "role_group_id", nullable = false)
	private RoleGroup roleGroup;
	@Column(name = "wrong_login_tries")
	private Integer wrongLoginTries = BigInteger.ZERO.intValue();
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "change_password_timestamp")
	private Date changePasswordTimestamp;
	@Column(name = "change_password_count")
	private Integer changePasswordCount;
	@OneToMany(cascade = {CascadeType.ALL}, fetch = FetchType.EAGER, mappedBy = "user")
	private Set<PasswordHistory> passwordHistories = new HashSet<PasswordHistory>(0);

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) throws NoSuchAlgorithmException {
		MessageDigest messageDigest = MessageDigest.getInstance("MD5");
		messageDigest.update(password.getBytes(), 0, password.length());
		String hashedPass = new BigInteger(1, messageDigest.digest()).toString(16);
		if (hashedPass.length() < 32) {
			hashedPass = "0" + hashedPass;
		}
		this.password = hashedPass;
	}

	public boolean isChangePassword() {
		return changePassword;
	}

	public void setChangePassword(boolean changePassword) {
		this.changePassword = changePassword;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
//		if (person.isNew()) {
			person.setUser(this);
//		}
		this.person = person;
	}

	public RoleGroup getRoleGroup() {
		return roleGroup;
	}

	public void setRoleGroup(RoleGroup roleGroup) {
		this.roleGroup = roleGroup;
	}

	public Integer getWrongLoginTries() {
		return wrongLoginTries;
	}

	public void setWrongLoginTries(Integer wrongLoginTries) {
		this.wrongLoginTries = wrongLoginTries;
	}

	public Date getChangePasswordTimestamp() {
		return changePasswordTimestamp;
	}

	public void setChangePasswordTimestamp(Date changePasswordTimestamp) {
		this.changePasswordTimestamp = changePasswordTimestamp;
	}

	public Integer getChangePasswordCount() {
		return changePasswordCount;
	}

	public void setChangePasswordCount(Integer changePasswordCount) {
		this.changePasswordCount = changePasswordCount;
	}

	public Set<PasswordHistory> getPasswordHistories() {
		return passwordHistories;
	}

	public void setPasswordHistories(Set<PasswordHistory> passwordHistories) {
		this.passwordHistories = passwordHistories;
	}
}
