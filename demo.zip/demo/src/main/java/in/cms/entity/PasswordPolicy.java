package in.cms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "password_policy")
public class PasswordPolicy extends AbstractAuditableEntity {

    

    @Column(name = "passwd_strength", length = 50, nullable = false)
    private String passwordStrength;
    
    @Column(name = "expiry_cycle", length = 3, nullable = false)
    private Integer expiryCycle;
    
    @Column(name = "history", length = 3, nullable = false)
    private Integer history;
    
    @Column(name = "num_changes", length = 3, nullable = false)
    private Integer numberOfChanges;
    
    @Column(name = "num_tries", length = 3, nullable = false)
    private Integer numberOfTries;
    
    @Column(name = "active")
    private Boolean active;
    
    @Column(name = "days", length = 3)
    private Integer days;
    
    @Column(name = "months", length = 3)
    private Integer months;
    
    @Column(name = "weeks", length = 3)
    private Integer weeks;


    public String getPasswordStrength() {
        return passwordStrength;
    }

    public void setPasswordStrength(String passwordStrength) {
        this.passwordStrength = passwordStrength;
    }


    public Integer getExpiryCycle() {
        return expiryCycle;
    }

    public void setExpiryCycle(Integer expiryCycle) {
        this.expiryCycle = expiryCycle;
    }

    public Integer getHistory() {
        return history;
    }

    public void setHistory(Integer history) {
        this.history = history;
    }

    public Integer getNumberOfChanges() {
        return numberOfChanges;
    }

    public void setNumberOfChanges(Integer numberOfChanges) {
        this.numberOfChanges = numberOfChanges;
    }

    public Integer getNumberOfTries() {
        return numberOfTries;
    }

    public void setNumberOfTries(Integer numberOfTries) {
        this.numberOfTries = numberOfTries;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Integer getDays() {
        return days;
    }

    public void setDays(Integer days) {
        this.days = days;
    }

    public Integer getMonths() {
        return months;
    }

    public void setMonths(Integer months) {
        this.months = months;
    }

    public Integer getWeeks() {
        return weeks;
    }

    public void setWeeks(Integer weeks) {
        this.weeks = weeks;
    }
    
}

