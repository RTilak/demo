package in.cms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import in.cms.enums.EmployeeType;
import in.cms.enums.PersonType;

@Entity
@Table(name = "employee")
public class Employee extends Person {

    private static final long serialVersionUID = -7076903084068122926L;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "employee_type", nullable = false)
    private EmployeeType employeeType;
    
    
    
    @Column(name = "e_mail")
    private String email;

    @Column(name = "phone")
    private String phone;
    
        public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public Employee() {
        super();
        setPersonType(PersonType.EMPLOYEE);
    }

    public EmployeeType getEmployeeType() {
        return employeeType;
    }

    public void setEmployeeType(EmployeeType employeeType) {
        this.employeeType = employeeType;
    }


    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}

