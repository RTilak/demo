package in.cms.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="password_history")
public class PasswordHistory extends AbstractAuditableEntity{
	
	@ManyToOne(cascade=CascadeType.ALL)
        @JoinColumn(name="user_id", nullable=false)
	private User user;
	
	@Column(name="password", length = 100, nullable=false)
	private String password;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
