package in.cms.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;

import in.cms.enums.EmployeeType;
import in.cms.enums.PersonType;
import in.cms.enums.Role;

@Entity
@Table(name = "role_group")
public class RoleGroup extends AbstractAuditableEntity {
	
	private static final long serialVersionUID = -5087868094942170113L;

	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "description")
	private String description;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "person_type", nullable = false)
	private PersonType personType;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "employee_type")
	private EmployeeType employeeType;
	
	@Column(name = "active", nullable = false)
	private boolean active;

	@ElementCollection(targetClass = Role.class)
	@JoinTable(name = "role_group_mapping", 
		joinColumns = @JoinColumn(name = "role_group_id", insertable=true,updatable=true)
	)
	@Column(name = "role", nullable = false)
	@Enumerated(EnumType.STRING)
	private Set<Role> roles = new HashSet<Role>();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public PersonType getPersonType() {
		return personType;
	}

	public void setPersonType(PersonType personType) {
		this.personType = personType;
	}

	public EmployeeType getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(EmployeeType employeeType) {
		this.employeeType = employeeType;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}
}
