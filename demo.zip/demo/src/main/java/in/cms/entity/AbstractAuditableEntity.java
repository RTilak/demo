package in.cms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

@MappedSuperclass
public abstract class AbstractAuditableEntity extends AbstractEntity {

    private static final long serialVersionUID = 7839509017490377322L;
    
    @Transient
    protected Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());
    
    @LastModifiedDate
    @Column(name = "last_modified_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdated;
    
    @LastModifiedBy
    @Column(name = "last_modified_by")
    private String lastUpdateUser;
    
    @CreatedDate
    @Column(name = "created_date", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    
    @CreatedBy
    @Column(name = "created_by", nullable = false)
    private String createUser;

    public Date getLastUpdated() {
        return lastUpdated;
    }

    public String getLastUpdateUser() {
        return lastUpdateUser;
    }

    public Date getCreated() {
        return created;
    }

    public String getCreateUser() {
        return createUser;
    }
}
