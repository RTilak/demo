package in.cms.entity;

import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

import org.hibernate.annotations.Parameter;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import org.jasypt.hibernate4.type.EncryptedDateAsStringType;
import org.jasypt.hibernate4.type.EncryptedIntegerAsStringType;
import org.jasypt.hibernate4.type.EncryptedStringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.domain.AbstractPersistable;


@TypeDefs
({
    @TypeDef (name="encryptedString", typeClass= EncryptedStringType.class,
        parameters= {
    @Parameter(name="encryptorRegisteredName", value="hibernateStringEncryptor")
    }
        ),
        @TypeDef (name="encryptedDate", typeClass= EncryptedDateAsStringType.class,
        parameters= {
        @Parameter(name="encryptorRegisteredName", value="hibernateStringEncryptor")
        }
            ),
            @TypeDef (name="encryptedInteger", typeClass= EncryptedIntegerAsStringType.class,
            parameters= {
            @Parameter(name="encryptorRegisteredName", value="hibernateStringEncryptor")
            }
                )
})

@MappedSuperclass
public abstract class AbstractEntity extends AbstractPersistable<Long> {

	@Override
    public void setId(Long id) {
        super.setId(id);
    }
    private static final long serialVersionUID = -4225997038976075861L; 
    @Transient
    protected Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());
}
