package in.cms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import in.cms.entity.Person;
import in.cms.entity.RoleGroup;
import in.cms.entity.User;
@Repository
public interface UserRepository extends JpaRepository<User, Long>, JpaSpecificationExecutor<User> {

	User findByUsername(String username);
	User findByPerson(Person person);
	List<User> findByRoleGroupAndPersonIn(RoleGroup roleGroup,List<Person> person);
	User findByUsernameAndRoleGroup(String mobileNo, RoleGroup roleGroup);
}
