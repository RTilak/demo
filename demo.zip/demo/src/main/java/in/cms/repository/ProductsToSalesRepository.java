package in.cms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.cms.entity.Products;
import in.cms.entity.ProductsToSales;

public interface ProductsToSalesRepository extends JpaRepository<ProductsToSales, Long>{

	ProductsToSales findByProducts(Products pro);

}
