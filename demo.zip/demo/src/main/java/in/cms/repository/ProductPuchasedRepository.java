package in.cms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.cms.entity.ProductPuchased;
import in.cms.entity.Products;

public interface ProductPuchasedRepository extends JpaRepository<ProductPuchased, Long>{

	ProductPuchased findByProducts(Products pro);

}
