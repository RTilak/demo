package in.cms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.cms.entity.Products;
import in.cms.entity.ProductsToProduction;

public interface ProductsToProductionRepository extends JpaRepository<ProductsToProduction, Long>{

	ProductsToProduction findByProducts(Products pro);

}
