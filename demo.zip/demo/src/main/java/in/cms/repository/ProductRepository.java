package in.cms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.cms.entity.Products;

public interface ProductRepository extends JpaRepository<Products, Long>{

}
