package in.cms.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;


public class ChangePasswordDto extends AbstractDto{
    
//  @NotBlank
  @Size(max=255)
  private String oldPassword;
  
  @NotBlank
  @Size(max=255)
  private String newPassword;
  
  @NotBlank
  @Size(max=255)
  private String newConfirmPassword;
  
 
//  @Valid
//  private List<SecurityQuestionDto> securityQuestions;
//  
//  @Valid
//  private List<SecurityAnswerDto> securityAnswers;
//
//  public List<SecurityAnswerDto> getSecurityAnswers() {
//      return securityAnswers;
//  }
//
//  public void setSecurityAnswers(List<SecurityAnswerDto> securityAnswers) {
//      this.securityAnswers = securityAnswers;
//  }
//  
  
//  public List<SecurityQuestionDto> getSecurityQuestions() {
//      return securityQuestions;
//  }
//
//  public void setSecurityQuestions(List<SecurityQuestionDto> securityQuestions) {
//      this.securityQuestions = securityQuestions;
//  }

  public String getNewConfirmPassword() {
      return newConfirmPassword;
  }

  public void setNewConfirmPassword(String newConfirmPassword) {
      this.newConfirmPassword = newConfirmPassword;
  }

  public String getOldPassword() {
      return oldPassword;
  }

  public void setOldPassword(String oldPassword) {
      this.oldPassword = oldPassword;
  }

  public String getNewPassword() {
      return newPassword;
  }

  public void setNewPassword(String newPassword) {
      this.newPassword = newPassword;
  }
}

