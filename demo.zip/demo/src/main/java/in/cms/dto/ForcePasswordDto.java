package in.cms.dto;

import org.hibernate.validator.constraints.NotBlank;


public class ForcePasswordDto extends ChangePasswordDto{

    @NotBlank
    private String username;
    
    private PasswordPolicyDto passwordPolicy;
    

    public PasswordPolicyDto getPasswordPolicy() {
		return passwordPolicy;
	}

	public void setPasswordPolicy(PasswordPolicyDto passwordPolicy) {
		this.passwordPolicy = passwordPolicy;
	}

	public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
