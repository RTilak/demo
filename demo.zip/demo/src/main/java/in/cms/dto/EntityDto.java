package in.cms.dto;


public class EntityDto extends AbstractDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4656078883919680177L;

	public EntityDto(){
		super();
	}
	
	public EntityDto(Long id, String name) {
		super(id);
		this.name = name;
	}
	
	private String name;

	public String fetchName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
