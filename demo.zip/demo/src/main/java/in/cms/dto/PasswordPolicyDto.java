package in.cms.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;


//@PasswordStrength(length = "length", digit = "numberLength", uppercase = "upperCaseLetterLength")
//@EitherOr(digit = "numberLength", uppercase = "upperCaseLetterLength")
public class PasswordPolicyDto extends AbstractDto{

    private static final long serialVersionUID = -8358761923894998203L;
    
    private String passwordStrength;
    
    @NotBlank
//    @Numeric
    @Max(value = 20)
    @Min(5)
    private String length;
    
    @NotBlank
//    @Numeric
    @Max(value = 20)
    private String upperCaseLetterLength;
    
    @NotBlank
//    @Numeric
    @Max(value = 20)
    private String numberLength;
    
    @NotBlank
    @Size(max = 18, min = 1)
//    @SpecialCharacter
    private String specialChar;
    
    @NotBlank
//    @Numeric
    @Max(value=31)
    private String noOfDay;
    
    @NotBlank
//    @Numeric
    @Max(value=52)
    private String noOfWeek;
    
    @NotBlank
//    @Numeric
    @Max(value=12)
    private String noOfMonth;
    
//    @NotEmpty
//    @Numeric
    private String expiryCycle;
    
    @NotBlank
//    @Numeric
    @Max(value=30)
    private String numberOfHistories;
    
    @NotBlank
//    @Numeric
    @Max(value=10)
    private String numberOfChanges;
    
    @NotBlank
//    @Numeric
    @Max(value=10)
    private String numberOfTries;

    public String getNoOfDay() {
        return noOfDay;
    }

    public void setNoOfDay(String noOfDay) {
        this.noOfDay = noOfDay;
    }

    public String getNoOfWeek() {
        return noOfWeek;
    }

    public void setNoOfWeek(String noOfWeek) {
        this.noOfWeek = noOfWeek;
    }

    public String getNoOfMonth() {
        return noOfMonth;
    }

    public void setNoOfMonth(String noOfMonth) {
        this.noOfMonth = noOfMonth;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public String getUpperCaseLetterLength() {
        return upperCaseLetterLength;
    }

    public void setUpperCaseLetterLength(String upperCaseLetterLength) {
        this.upperCaseLetterLength = upperCaseLetterLength;
    }

    public String getNumberLength() {
        return numberLength;
    }

    public void setNumberLength(String numberLength) {
        this.numberLength = numberLength;
    }

    public String getSpecialChar() {
        return specialChar;

    }

    public void setSpecialChar(String specialChar) {
        this.specialChar = specialChar;
    }

    public String getPasswordStrength() {
        return passwordStrength;
    }

    public void setPasswordStrength(String passwordStrength) {
        this.passwordStrength = passwordStrength;
    }

    public String getExpiryCycle() {
        return expiryCycle;
    }

    public void setExpiryCycle(String expiryCycle) {
        this.expiryCycle = expiryCycle;
    }

    public String getNumberOfHistories() {
        return numberOfHistories;
    }

    public void setNumberOfHistories(String numberOfHistories) {
        this.numberOfHistories = numberOfHistories;
    }

    public String getNumberOfChanges() {
        return numberOfChanges;
    }

    public void setNumberOfChanges(String numberOfChanges) {
        this.numberOfChanges = numberOfChanges;
    }

    public String getNumberOfTries() {
        return numberOfTries;
    }

    public void setNumberOfTries(String numberOfTries) {
        this.numberOfTries = numberOfTries;
    }
}

