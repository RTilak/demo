package in.cms.dto;

import java.io.Serializable;

import javax.persistence.Transient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AbstractDto implements Serializable{
	
	 private static final long serialVersionUID = -8866237841476695337L;
	    private Long id;
	    private String formValidateRandomName;
		private String formValidateRandomValue;

	    @Transient
	    protected Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());

	    public AbstractDto(Long id) {
	    	this();
			this.id = id;
		}

		public AbstractDto() {
			super();
		}

		public Long getId() {
	        return id;
	    }
	    
	    public void setId(Long id) {
	        this.id = id;
	    }
	    public String getFormValidateRandomName() {
			return formValidateRandomName;
		}

		public void setFormValidateRandomName(String formValidateRandomName) {
			this.formValidateRandomName = formValidateRandomName;
		}

		public String getFormValidateRandomValue() {
			return formValidateRandomValue;
		}

		public void setFormValidateRandomValue(String formValidateRandomValue) {
			this.formValidateRandomValue = formValidateRandomValue;
		}

		@Override
		public int hashCode() {
			int hash = 7;
			hash = 41 * hash + (this.id != null ? this.id.hashCode() : 0);
			return hash;
		}

		@Override
		public boolean equals(Object obj) {
			if (obj == null) {
				return false;
			}
			if (getClass() != obj.getClass()) {
				return false;
			}
			final AbstractDto other = (AbstractDto) obj;
			if (this.id == null || !this.id.equals(other.id)) {
				return false;
			}
			return true;
		}	

}
