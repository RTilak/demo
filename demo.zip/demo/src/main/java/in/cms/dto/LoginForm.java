package in.cms.dto;

import org.hibernate.validator.constraints.NotBlank;

public class LoginForm {

    @NotBlank
    private String j_username;
    
    @NotBlank
    private String j_password;
    
    private Boolean spring_security_remember_me = false;

    public Boolean getSpring_security_remember_me() {
        return spring_security_remember_me;
    }

    public void setSpring_security_remember_me(Boolean spring_security_remember_me) {
        this.spring_security_remember_me = spring_security_remember_me;
    }

    public String getJ_username() {
        return j_username;
    }

    public void setJ_username(String j_username) {
        this.j_username = j_username;
    }

    public String getJ_password() {
        return j_password;
    }

    public void setJ_password(String j_password) {
        this.j_password = j_password;
    }
}

