package in.cms.authentication;

import java.io.IOException;
import java.lang.annotation.ElementType;
import java.lang.reflect.Field;
import java.security.Provider;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.inject.Inject;
import javax.persistence.EntityManagerFactory;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import javax.validation.Path;
import javax.validation.Path.Node;
import javax.validation.constraints.NotNull;

import org.apache.commons.dbcp.BasicDataSource;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.hibernate.validator.engine.resolver.DefaultTraversableResolver;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.hibernate4.encryptor.HibernatePBEStringEncryptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaDialect;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaDialect;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.ExceptionMappingAuthenticationFailureHandler;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.util.ReflectionUtils;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;


@Configuration
@EnableTransactionManagement
@EnableScheduling 
@ImportResource({
	"classpath:audit-context.xml",
	"classpath:security-context.xml"
})
@PropertySource({
	"classpath:database.properties",
	"classpath:application_conf.properties"
})
@EnableJpaRepositories(basePackages = {
		"in.cms.repository"
})
@ComponentScan(basePackages = {
		"in.cms"
})
public class ApplicationConfig {

	@Inject
	Environment env;

	@Bean
	public DataSource dataSource() {
		BasicDataSource bds = new BasicDataSource();

//		String client = env.getProperty("app.conf.client");
//		if(client == null || client.isEmpty()) {
//			client = "";
//		}else{ 
//			client += "."; 
//		}

		bds.setDriverClassName(env.getProperty("jdbc.driverClassName"));
		bds.setUrl(env.getProperty("jdbc.url"));
		bds.setUsername(env.getProperty("jdbc.username"));
		bds.setPassword(env.getProperty("jdbc.password"));


		bds.setInitialSize(10);
		bds.setMaxActive(200);
		bds.setMinIdle(10);
		bds.setMaxIdle(50);
		bds.setPoolPreparedStatements(false);
		bds.setDefaultAutoCommit(true);
		bds.setDefaultTransactionIsolation(1);
		bds.setTestOnBorrow(true);
		bds.setTimeBetweenEvictionRunsMillis(10000);
		bds.setMinEvictableIdleTimeMillis(600000);
		//        bds.setValidationQuery("select 1 from dual");

		return bds;
	}

	@Bean
	public EntityManagerFactory entityManagerFactory() {
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
//		String client = env.getProperty("app.conf.client");
//		if(client == null || client.isEmpty()) {
//			client = "";
//		}else{ 
//			client += "."; 
//		}
		if (env.getProperty("database.type") != null
				&& "MSSQL".equalsIgnoreCase(env.getProperty("database.type"))) {
			vendorAdapter.setDatabase(Database.SQL_SERVER);
		} else if (env.getProperty("database.type") != null
				&& "MYSQL".equalsIgnoreCase(env.getProperty("database.type"))) {
			vendorAdapter.setDatabase(Database.MYSQL);
		}
		//database.showSql
//        String showSql = env.getProperty("database.showSql");        
//        vendorAdapter.setShowSql(new Boolean(showSql));
        vendorAdapter.setGenerateDdl(true); // create table structure

		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
		factory.setJpaVendorAdapter(vendorAdapter);
		factory.setPackagesToScan(
				"in.cms.entity");
		factory.setDataSource(dataSource());

		factory.afterPropertiesSet();

		return factory.getObject();
	}

	@Bean
	public JpaDialect jpaDialect() {
		return new HibernateJpaDialect();
	}

	@Bean
	public PlatformTransactionManager transactionManager() {
		JpaTransactionManager txManager = new JpaTransactionManager();
		txManager.setEntityManagerFactory(entityManagerFactory());
		return txManager;
	}


	@Bean
	public ExceptionMappingAuthenticationFailureHandler exceptionTranslationFilter() {
		ExceptionMappingAuthenticationFailureHandler empaf = new ExceptionMappingAuthenticationFailureHandler();
		empaf.setDefaultFailureUrl("/login?login_error=1");
		Map<String, String> failureUrlMap = new HashMap<String, String>();
		failureUrlMap.put("org.springframework.security.authentication.BadCredentialsException", "/login?login_error=1");
		failureUrlMap.put("org.springframework.security.authentication.CredentialsExpiredException", "/force-change-password");
		failureUrlMap.put("org.springframework.security.authentication.LockedException", "/login?login_error=2");
		failureUrlMap.put("org.springframework.security.authentication.DisabledException", "/login?login_error=3");
		empaf.setExceptionMappings(failureUrlMap);
		return empaf;
	}

//	@Bean
//	public SimpleMappingExceptionResolver fromRandomNumExceptionHandler() {
//		SimpleMappingExceptionResolver smer = new SimpleMappingExceptionResolver();
//
//		Properties properties = new Properties();
//		properties.setProperty("java.lang.Exception", "exception");
//		properties.setProperty("java.lang.RuntimeException", "exception");
//
//		smer.setExceptionMappings(properties);
//
//		smer.setDefaultErrorView("redirect:/?msg=Unknown Exception occured, please contact administrator");
//
//		return smer;
//	}

	@Bean 
	public AuthenticationSuccessHandler authenticationSuccessHandler(){
		return new  AuthenticationSuccessHandler() {
			
			public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
					Authentication authentication) throws IOException, ServletException {
				Set<String> roles = AuthorityUtils.authorityListToSet(authentication.getAuthorities());
				//                if (roles.contains("ROLE_USER") 
				response.sendRedirect("");
			}
		};
	}
}
