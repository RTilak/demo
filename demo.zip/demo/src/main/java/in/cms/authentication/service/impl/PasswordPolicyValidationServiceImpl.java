package in.cms.authentication.service.impl;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;

import javax.inject.Inject;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.stereotype.Service;

import in.cms.authentication.service.PasswordPolicyValidationService;
import in.cms.dto.PasswordPolicyDto;
import in.cms.entity.Employee;
import in.cms.entity.PasswordHistory;
import in.cms.entity.PasswordPolicy;
import in.cms.entity.User;
import in.cms.enums.PasswordPolicyViolation;
import in.cms.repository.EmployeeRepository;
import in.cms.repository.PasswordPolicyRepository;
import in.cms.repository.UserRepository;
import in.cms.validation.PasswordComplexityValidator;

@Service
public class PasswordPolicyValidationServiceImpl 
    implements  PasswordPolicyValidationService {

    private static final Random RANDOM = new SecureRandom();
    @Inject
    private PasswordPolicyRepository passwordPolicyRepository;
    @Inject
    private UserRepository userRepository;
    @Inject
    private EmployeeRepository employeeRepository;
    public static final String DEFAULT_PASSWORD_STRENGTH = "20P1U1N1S";
    public static final String MIN_PASSWORD_LENGTH = "5";

    public List<PasswordPolicyViolation> validateLogin(Long userId) {
        User user = userRepository.findOne(userId);
        
        List<PasswordPolicyViolation> violations = new ArrayList<PasswordPolicyViolation>();
        PasswordPolicy policy = null;
        Employee employee = employeeRepository.findOne(user.getPerson().getId());
        if (employee != null) {
            policy = passwordPolicyRepository.findOne(1L);
        } else {
            policy = generateVisitorPolicy();
        }

        //Check Max Login Tries
        if (policy != null && policy.getNumberOfTries() != null
                && policy.getNumberOfTries() > 0 && user.getWrongLoginTries() >= policy.getNumberOfTries()) {
            violations.add(new PasswordPolicyViolation(PasswordPolicyViolation.Type.FAILED_LOGIN_TRIES, policy));
        }


        //Check Expiry Cycle
        if (policy != null && policy.getExpiryCycle() != null && policy.getExpiryCycle() > 0
                && user.getChangePasswordTimestamp() != null) {
            //Date expirationDate = DateUtils.addMonths(user.getChangePasswordTimestamp(), policy.getExpiryCycle());
            Date expirationDate = DateUtils.addDays(user.getChangePasswordTimestamp(), policy.getExpiryCycle());
            if (DateUtils.truncatedCompareTo(expirationDate, new Date(), Calendar.DATE) <= 0) {
                violations.add(new PasswordPolicyViolation(PasswordPolicyViolation.Type.EXPIRY_CYCLE, policy));
            }
        }

        return violations;
    }

    public List<PasswordPolicyViolation> validateChangePassword(User user, String password) {
        List<PasswordPolicyViolation> violations = new ArrayList<PasswordPolicyViolation>();
        Employee employee = employeeRepository.findOne(user.getPerson().getId());
        PasswordPolicy policy = null;
        if (employee != null) {
            policy = passwordPolicyRepository.findOne(1L);
        }
        if(policy == null){
            policy = generateVisitorPolicy();
        }

        violations.addAll(validateCommonChangePassword(user, policy, password, Boolean.FALSE));

        //Check Number of login changes
        if (policy != null && policy.getNumberOfChanges() != null && policy.getNumberOfChanges() > 0
                && user.getChangePasswordCount() != null && user.getChangePasswordTimestamp() != null) {
            if (DateUtils.truncatedCompareTo(user.getChangePasswordTimestamp(), new Date(), Calendar.DATE) == 0
                    && user.getChangePasswordCount() >= policy.getNumberOfChanges()) {
                violations.add(new PasswordPolicyViolation(PasswordPolicyViolation.Type.MAX_CHANGES, policy));
            }
        }
        return violations;
    }

    public List<PasswordPolicyViolation> validateForcedChangePassword(User user, String password, boolean isFirstTime) {
        Employee employee = employeeRepository.findOne(user.getPerson().getId());
        PasswordPolicy policy = null;
        if (employee != null) {
        	policy = passwordPolicyRepository.findOne(1L);
        } else {
            policy = generateVisitorPolicy();
        }
        return validateCommonChangePassword(user, policy, password, isFirstTime);
    }

    public List<PasswordPolicyViolation> validateCommonChangePassword(
            User user, PasswordPolicy policy, String password, boolean forceSkipCurrentPassword) {
        List<PasswordPolicyViolation> violations = new ArrayList<PasswordPolicyViolation>();

        //Check Password Strength
        String passwordStrength = DEFAULT_PASSWORD_STRENGTH;
        if (policy != null && policy.getPasswordStrength() != null) {
            passwordStrength = policy.getPasswordStrength();
        }
        Map passwordStrengthValue = getValueFromPasswordStrength(passwordStrength);

        PasswordComplexityValidator validator = new PasswordComplexityValidator(Integer.parseInt(MIN_PASSWORD_LENGTH), (Integer) passwordStrengthValue.get("length"),
                0, (Integer) passwordStrengthValue.get("upperCaseLength"), (Integer) passwordStrengthValue.get("specialCharLength"),
                (Integer) passwordStrengthValue.get("digitLength"), (String) passwordStrengthValue.get("specialChar"));
        try {
            validator.validatePassword(password);
        } catch (Exception e) {
            violations.add(new PasswordPolicyViolation(PasswordPolicyViolation.Type.CUSTOM, e.getMessage()));
        }

        //Check Password History
        if (policy != null && policy.getHistory() != null && policy.getHistory() > 0) {
            List<String> encryptedPasswords = new ArrayList<String>();
//            if (!user.isChangePassword()) {
//                if (!forceSkipCurrentPassword) {
//                    encryptedPasswords.add(user.getPassword());
//                }
//            }
            password=getHashedPassword(password);
            encryptedPasswords.addAll(extractAndSortPasswordHistories(user.getPasswordHistories()));          
            int i = 0;
            boolean reuse = false;
            for (String encryptedPassword : encryptedPasswords) {                 
                if (StringUtils.equals(encryptedPassword, password)) {
                    reuse = true;
                    break;
                }

                if (i >= policy.getHistory() - 1) {
                    break;
                }
                i++;
            }
            if (reuse) {
                violations.add(new PasswordPolicyViolation(PasswordPolicyViolation.Type.HISTORY_REUSE, policy));
            }
        }

        return violations;
    }

    private List<String> extractAndSortPasswordHistories(Set<PasswordHistory> passwordHistories) {
        Map<Date, String> historyMap = new TreeMap<Date, String>();
        for (PasswordHistory history : passwordHistories) {
            historyMap.put(history.getCreated(), history.getPassword());
        }

        List<String> sortedHistoryList = new ArrayList<String>();
        Iterator<Date> iterator = historyMap.keySet().iterator();
        while (iterator.hasNext()) {
            sortedHistoryList.add(historyMap.get(iterator.next()));
        }

        Collections.reverse(sortedHistoryList);
        System.out.println("testin2");
        return sortedHistoryList;
    }

    public String generateRandomPassword(User user) {
        Employee employee = employeeRepository.findOne(user.getPerson().getId());
        PasswordPolicy policy = null;
        if (employee != null) {
        	policy = passwordPolicyRepository.findOne(1L);
        } else {
            policy = generateVisitorPolicy();
        }
        return generateRandomPassword(policy);
    }

    public String generateRandomPassword(PasswordPolicy policy) {
        String passwordStrength = DEFAULT_PASSWORD_STRENGTH;
        if (policy != null && policy.getPasswordStrength() != null) {
            passwordStrength = policy.getPasswordStrength();
        }
        Map passwordStrengthValue = getValueFromPasswordStrength(passwordStrength);
        int min = Integer.parseInt(MIN_PASSWORD_LENGTH);
        int max = (Integer) passwordStrengthValue.get("length");
        int base = min - 1;
        int minMaxDiff = (max - min) + 1;
        int passwordLength = base + RANDOM.nextInt(minMaxDiff);

        return RandomStringUtils.randomAlphanumeric(passwordLength);
    }

    private PasswordPolicy generateVisitorPolicy() {
        PasswordPolicy pp = new PasswordPolicy();

        pp.setPasswordStrength("20P1U1N9S643536373833424041");
        pp.setDays(0);
        pp.setWeeks(0);
        pp.setMonths(3);
        pp.setHistory(3);
        pp.setExpiryCycle(5);
        pp.setNumberOfChanges(0);
        pp.setNumberOfTries(5);
        pp.setActive(Boolean.TRUE);

        return pp;
    }

    public Map getValueFromPasswordStrength(String passwordStreangth) {
        if (passwordStreangth == null || passwordStreangth.equals("")) {
            passwordStreangth = DEFAULT_PASSWORD_STRENGTH;
        }
        passwordStreangth = passwordStreangth.trim();
        int length = 20;
        int digitLength = 0;
        int upperCaseLength = 0;
        int specialCharLength = 0;
        String specialChar = "";
        int start = 0;
        Map map = new HashMap();
        for (int i = 0; i < passwordStreangth.length(); i++) {
            if (passwordStreangth.charAt(i) == 'P') {
                if (passwordStreangth.indexOf('P') != 0) {
                    length = Integer.parseInt(passwordStreangth.substring(start, passwordStreangth.indexOf('P')));
                    start = passwordStreangth.indexOf('P') + 1;
                } else {
                    start = 1;
                }
            }
            if (passwordStreangth.charAt(i) == 'U') {
                upperCaseLength = Integer.parseInt(passwordStreangth.substring(start, passwordStreangth.indexOf('U')));
                start = passwordStreangth.indexOf('U') + 1;
            }
            if (passwordStreangth.charAt(i) == 'N') {
                digitLength = Integer.parseInt(passwordStreangth.substring(start, passwordStreangth.indexOf('N')));
                start = passwordStreangth.indexOf('N') + 1;
            }
            if (passwordStreangth.charAt(i) == 'S') {
                specialCharLength = Integer.parseInt((passwordStreangth.substring(start, passwordStreangth.indexOf('S')).equals("")) ? "0" : (passwordStreangth.substring(start, passwordStreangth.indexOf('S'))));
                if ((passwordStreangth.indexOf('S') + 1) < passwordStreangth.length()) {
                    if (passwordStreangth.charAt(i + 1) == 'E') {
                        specialCharLength = 1;
                    } else {

                        for (int j = passwordStreangth.indexOf('S') + 1; j < passwordStreangth.length(); j += 2) {
                            specialChar += (char) Integer.parseInt(passwordStreangth.substring(j, j + 2)) + ",";
                        }
                    }
                }
            }
        }
        specialChar = (specialChar.equals("") && specialCharLength > 0) ? "@,#,$,%,&,!,*,(,)" : (specialChar.substring(0, (specialChar.length() - 1)));
        map.put("length", length);
        map.put("digitLength", digitLength);
        map.put("upperCaseLength", upperCaseLength);
        map.put("specialChar", specialChar);
        map.put("specialCharLength", specialCharLength);
        return map;
    }

    public Map getNumberInDaysWeekAndMonth(Integer numberOfChanges) {
        Map map = new HashMap();
        if (numberOfChanges > 31) {
            if (numberOfChanges > 365) {
                map.put("month", 12);
                numberOfChanges = numberOfChanges - 365;
            }
            if (numberOfChanges > 31) {
                if (numberOfChanges % 7 != 0) {
                    int week = numberOfChanges / 7;
                    int day = numberOfChanges - (week * 7);
                    map.put("day", day);
                    map.put("week", week);
                } else {
                    map.put("week", (numberOfChanges / 7));
                }
            } else {
                map.put("day", numberOfChanges);
            }
        } else {
            map.put("day", numberOfChanges);
        }
        return map;
    }

    public Map getPasswordStrengthByUser(User user) {
        Employee employee = employeeRepository.findOne(user.getPerson().getId());
        PasswordPolicy policy = null;
        if (employee != null) {
        	policy = passwordPolicyRepository.findOne(1L);
        } else {
            policy = generateVisitorPolicy();
        }
        Map map = new HashMap();
        if (policy == null || policy.getPasswordStrength() == null || policy.getPasswordStrength().equals("")) {
            policy = new PasswordPolicy();
            policy.setPasswordStrength(DEFAULT_PASSWORD_STRENGTH);
            map.put("emptyPasswordPolicy", "Please Contact Administrator to create password policy");
        }
        map.putAll(getValueFromPasswordStrength(policy.getPasswordStrength()));
        map.put("passwordStrengthType", policy.getPasswordStrength());
        return map;
    }
     public String getHashedPassword(String rawPassword) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(rawPassword.getBytes(), 0, rawPassword.length());
            String hashedPass = new BigInteger(1, messageDigest.digest()).toString(16);
            if (hashedPass.length() < 32) {
                hashedPass = "0" + hashedPass;
            }
            return hashedPass;
        } catch (NoSuchAlgorithmException ex) {
            return ex.getMessage();
        }
    }
}

