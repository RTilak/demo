package in.cms.authentication.service;

import java.util.List;
import java.util.Map;

import in.cms.entity.PasswordPolicy;
import in.cms.entity.User;
import in.cms.enums.PasswordPolicyViolation;


public interface PasswordPolicyValidationService {
	
	List<PasswordPolicyViolation> validateLogin(Long userId);

	List<PasswordPolicyViolation> validateChangePassword(User user, String password);

	List<PasswordPolicyViolation> validateForcedChangePassword(User user, String password, boolean isFirstTime);

	String generateRandomPassword(User user);

	String generateRandomPassword(PasswordPolicy pp);

	Map getValueFromPasswordStrength(String passwordStreangth);

	Map getNumberInDaysWeekAndMonth(Integer numberOfChanges);

	Map getPasswordStrengthByUser(User user);
	
}
