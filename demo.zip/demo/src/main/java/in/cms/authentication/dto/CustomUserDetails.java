package in.cms.authentication.dto;

import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;

import in.cms.entity.Employee;
import in.cms.entity.Person;
import in.cms.enums.EmployeeType;
import in.cms.enums.PersonType;

public class CustomUserDetails extends User {

	private static final long serialVersionUID = -8944721793558267854L;
	private Integer userId;
	private String firstName;
	private String middleName;
	private String lastName;
	private PersonType personType;
	private EmployeeType employeeType;
	private String mobileNumber;
	private String email;
	/**
	 * organization is used as user organization which is normal behavior
	 * organization is used as current selected organization for super admin.
	 */
	private Long orgEstablishmentType;

	public CustomUserDetails(in.cms.entity.User user, List<GrantedAuthority> authorities) {
		super(user.getUsername(), user.getPassword(), user.isActive(), user.isActive(), !user.isChangePassword(),
				true, authorities);
		Person person = user.getPerson();
		setUserId(user.getId().intValue());
		setFirstName(person.getFirstName());
		setMiddleName(person.getMiddleName());
		setLastName(person.getLastName());
		setPersonType(person.getPersonType());

		try{
			Employee employee = (Employee) person;
			setEmployeeType(employee.getEmployeeType());
			setMobileNumber(employee.getPhone());
			setEmail(employee.getEmail());;
		}catch (Exception e) {
			System.out.println("person cast to employee exception");
		}
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public PersonType getPersonType() {
		return personType;
	}

	public void setPersonType(PersonType personType) {
		this.personType = personType;
	}

	public EmployeeType getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(EmployeeType employeeType) {
		this.employeeType = employeeType;
	}

	public Long getOrgEstablishmentType() {
		return orgEstablishmentType;
	}

	public void setOrgEstablishmentType(Long orgEstablishmentType) {
		this.orgEstablishmentType = orgEstablishmentType;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 41 * hash + (this.userId != null ? this.userId.hashCode() : 0);
		return hash;
	}


	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final CustomUserDetails other = (CustomUserDetails) obj;
		if (this.userId != other.userId && (this.userId == null || !this.userId.equals(other.userId))) {
			return false;
		}
		return true;
	}



	public static CustomUserDetails getUserDetails() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if ((authentication != null) && (authentication.getPrincipal() instanceof CustomUserDetails)) {
			return ((CustomUserDetails) authentication.getPrincipal());
		}
		return null;
	}
}

