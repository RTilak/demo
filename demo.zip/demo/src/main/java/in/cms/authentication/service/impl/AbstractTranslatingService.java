//package in.cms.authentication.service.impl;
//
//import java.lang.reflect.ParameterizedType;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Map.Entry;
//
//import javax.inject.Inject;
//
//import org.apache.poi.ss.formula.functions.T;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.PageImpl;
//import org.springframework.data.domain.Pageable;
//
//import in.cms.dto.AbstractDto;
//import in.cms.entity.AbstractEntity;
////import ma.glasnost.orika.MapperFacade;
//
//
//public abstract class AbstractTranslatingService<S extends AbstractEntity, D extends AbstractDto> {
//
//	private static final long serialVersionUID = -7357689523669630327L;
//	protected Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());
//
//	private Class<S> entityClass;
//	private Class<D> dtoClass;
//
////	@Inject
////	private MapperFacade mapper;
//
//	@SuppressWarnings("unchecked")
//	public AbstractTranslatingService() {
//		this.entityClass = (Class<S>) ((ParameterizedType) getClass()
//				.getGenericSuperclass()).getActualTypeArguments()[0];
//
//		this.dtoClass = (Class<D>) ((ParameterizedType) getClass()
//				.getGenericSuperclass()).getActualTypeArguments()[1];
//	}
//
//	protected List<D> translateFromEntity(List<S> entities) {
//		List<D> dtos = new ArrayList<D>();
//		for (S entity : entities) {
//			dtos.add(translateFromEntity(entity));
//		}
//		return dtos;
//	}
//
//	protected Map<T,D> translateFromEntity(Map<T,S> entities) {
//		Map<T,D> dtos = new HashMap<T,D>();
//		for (Entry<T,S> entitySet : entities.entrySet()) {
//			dtos.put(entitySet.getKey(),translateFromEntity(entitySet.getValue()));
//		}
//		return dtos;
//	}
//
////	protected D translateFromEntity(S entity) {
//////		return mapper.map(entity, dtoClass);
////	}
//
//	protected List<S> translateToEntity(List<D> dtos) {
//		List<S> entities = new ArrayList<S>();
//		for (D dto : dtos) {
//			entities.add(translateToEntity(dto));
//		}
//		return entities;
//	}
//
//	protected Map<T,S> translateToEntity(Map<T,D> dtos) {
//		Map<T,S> entities = new HashMap<T,S>();
//		for (Entry<T,D> dtoEntry : dtos.entrySet()) {
//			entities.put(dtoEntry.getKey(),translateToEntity(dtoEntry.getValue()));
//		}
//		return entities;
//	}
//
////	protected S translateToEntity(D dto) {
//////		return mapper.map(dto, entityClass);
////	}
//
////	protected MapperFacade getMapper() {
////		return mapper;
////	}
//
//	protected Page<D> translateFromEntity(Page<S> entities, Pageable page ) {
//		List<D> dtos = new ArrayList<D>();
//		for (S entity : entities.getContent()) {
//			dtos.add(translateFromEntity(entity));
//		}
//		return new PageImpl<D>(dtos, page, entities.getTotalElements());
//	}
//
//	protected Page<S> translateToEntity(Page<D> dtos, Pageable page) {
//		List<S> entities = new ArrayList<S>();
//		for (D dto : dtos.getContent()) {
//			entities.add(translateToEntity(dto));
//		}
//		return new PageImpl<S>(entities, page, dtos.getTotalElements());
//	}
//
//	protected <E,F> List<E> translateToList(List<F> list, Class<E> cls){
//		List<E> newList = new ArrayList<E>();
//		for(F f : list){
//			newList.add(mapper.map(f, cls));
//		}
//		return newList;
//	}
//
//	protected <E,F> E translate(F f, Class<E> cls){
//		return mapper.map(f, cls);
//	}
//
//	protected <E,F> Page<E> translateToPage(Page<F> page, Class<E> cls, Pageable pageable){
//		List<E> newList = translateToList(page.getContent(), cls);
//		return new PageImpl<E>(newList, pageable, page.getTotalElements());
//	}
//}
//
