package in.cms.validation;

import java.util.StringTokenizer;


public class PasswordComplexityValidator {
	
    // For character determinations
    public static final int CHAR_LOWER_A = 'a';
    public static final int CHAR_LOWER_Z = 'z';
    public static final int CHAR_UPPER_A = 'A';
    public static final int CHAR_UPPER_Z = 'Z';
    public static final int CHAR_NUMERIC_ZERO = '0';
    public static final int CHAR_NUMERIC_NINE = '9';
    // Since the alpha and numeric checks handle the [a-zA-Z0-9] case in
    // earlier if statement checks, we can then assume the surrounding characters
    // within the range of the special char lower and upper values are in fact
    // special characters.  If it extends past the range, then it's no longer a symbol.
    public static final int CHAR_LOWER_SPECIAL_CHAR = ' ';
    public static final int CHAR_UPPER_SPECIAL_CHAR = '~';
    // Configurable variables
    private int minPasswordLength = 5;
    private int maxPasswordLength = 20;
    private int minLowerAlphaChars = 1;
    private int minUpperAlphaChars = 1;
    private int minSpecialChars = 1;
    private int minNumericalChars = 1;
    private CustomPasswordComplexityValidation[] customValidations;
    private String specialChar = "@";

    public PasswordComplexityValidator(int newMinPasswordLength, int newMaxPasswordLength,
            int newMinLowerAlphaChars, int newMinUpperAlphaChars, int newMinSpecialChars,
            int newMinNumericalChars, CustomPasswordComplexityValidation... customValidations) {
        this.minPasswordLength = newMinPasswordLength;
        this.maxPasswordLength = newMaxPasswordLength;
        this.minLowerAlphaChars = newMinLowerAlphaChars;
        this.minUpperAlphaChars = newMinUpperAlphaChars;
        this.minSpecialChars = newMinSpecialChars;
        this.minNumericalChars = newMinNumericalChars;
        this.customValidations = customValidations;
    }

    public PasswordComplexityValidator(int newMinPasswordLength, int newMaxPasswordLength,
            int newMinLowerAlphaChars, int newMinUpperAlphaChars, int newMinSpecialChars,
            int newMinNumericalChars, String SpecialChar) {
        this.minPasswordLength = newMinPasswordLength;
        this.maxPasswordLength = newMaxPasswordLength;
        this.minLowerAlphaChars = newMinLowerAlphaChars;
        this.minUpperAlphaChars = newMinUpperAlphaChars;
        this.minSpecialChars = newMinSpecialChars;
        this.minNumericalChars = newMinNumericalChars;
        this.specialChar = SpecialChar;
    }

    public PasswordComplexityValidator() {
    }
    
     public void validatePassword(String password) throws Exception {
        int passwordLen = password.length();

        if (passwordLen < minPasswordLength) {
            throw new Exception("The password must be at least " + minPasswordLength + " characters in length.");
        }

        if (passwordLen > maxPasswordLength) {
            throw new Exception("The password must be at less than " + maxPasswordLength + " characters in length.");
        }

        int alphaLowerCharsCount = 0;
        int alphaUpperCharsCount = 0;
        int numericCharsCount = 0;
        int specialCharsCount = 0;

        // Count the characters
        char passwordChar;
        for (int i = 0; i < passwordLen; i++) {
            passwordChar = password.charAt(i);
            if (passwordChar >= CHAR_LOWER_A && passwordChar <= CHAR_LOWER_Z) {
                alphaLowerCharsCount++;
            } else if (passwordChar >= CHAR_UPPER_A && passwordChar <= CHAR_UPPER_Z) {
                alphaUpperCharsCount++;
            } else if (passwordChar >= CHAR_NUMERIC_ZERO && passwordChar <= CHAR_NUMERIC_NINE) {
                numericCharsCount++;
//            } else if (passwordChar > CHAR_LOWER_SPECIAL_CHAR && passwordChar <= CHAR_UPPER_SPECIAL_CHAR) {
//                specialCharsCount++;
//            } 
            } else if (checkSpecialCharacter(passwordChar)) {
                specialCharsCount++;
            } else {
                throw new Exception("Invalid password character entered.  You can use: a-z, A-Z, 0-9, Symbols("+specialChar+")");
            }
        }

        if (alphaLowerCharsCount < minLowerAlphaChars) {
            throw new Exception("The password must contain at least " + minLowerAlphaChars + " lowercase alpha (a-z) characters.");
        }

        if (alphaUpperCharsCount < minUpperAlphaChars) {
            throw new Exception("The password must contain at least " + minUpperAlphaChars + " uppercase alpha (A-Z) characters.");
        }

        if (numericCharsCount < minNumericalChars) {
            throw new Exception("The password must contain at least " + minNumericalChars + " numerical (0-9) characters.");
        }

        if (specialCharsCount < 1){//minSpecialChars) {
            throw new Exception("The password must contain at least " + 1 + " special (symbols such as:"+specialChar+") characters.");
        }

        //Custom validations
        if (customValidations != null && customValidations.length > 0) {
            for (CustomPasswordComplexityValidation customValidation : customValidations) {
                customValidation.validate(password);
            }
        }
    }

    public interface CustomPasswordComplexityValidation {

        void validate(String password) throws Exception;
    }
    
    private boolean checkSpecialCharacter(Character passChar) {
        StringTokenizer st = new StringTokenizer(specialChar, ",");
        boolean flag = false;
        while (st.hasMoreTokens()) {
            String ch = st.nextToken();
            if (ch.charAt(0) == passChar) {
                flag = true;
                return flag;
            }
        }
        return flag;
    }
}

