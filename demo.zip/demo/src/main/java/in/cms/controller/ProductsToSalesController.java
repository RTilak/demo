package in.cms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import in.cms.dto.ProductPuchasedDto;
import in.cms.dto.ProductsToSalesDto;
import in.cms.entity.ProductsToProduction;
import in.cms.entity.ProductsToSales;
import in.cms.service.ProductService;
import in.cms.service.ProductsToProductionService;
import in.cms.service.ProductsToSalesService;

@Controller
@RequestMapping(value="/product/sales")
public class ProductsToSalesController {
	
	@Autowired
	private ProductsToSalesService productsToSalesService;
	@Autowired
	private ProductsToProductionService productsToProductionService;
	@Autowired
	private ProductService productService;
	
	
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String getPurchase(Model model,Pageable page) {
		model.addAttribute("products", productService.findAll());
		model.addAttribute("model", new ProductPuchasedDto());
		model.addAttribute("page", productsToSalesService.findAll(page));
		return "cms/productToSales";
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String savePurchase(@ModelAttribute("model") ProductsToSalesDto dto,Model model,Pageable page) {
		
		ProductsToSales productPuchased=productsToSalesService.findByProductId(dto.getProductId());
		if(productPuchased!=null && dto.getId() == null){
			model.addAttribute("products", productService.findAll());
			model.addAttribute("page", productsToSalesService.findAll(page));
			model.addAttribute("duplicate", true);
			return "cms/productToSales";
		}
		
		ProductsToProduction proPur=productsToProductionService.findByProductId(dto.getProductId());
		if(proPur == null) {
			model.addAttribute("products", productService.findAll());
			model.addAttribute("page", productsToProductionService.findAll(page));
			model.addAttribute("error", "Product Should be purchased to forward it to production ");
			return "cms/productToPurchase";
		}
		if(proPur !=null && proPur.getQuantity()<dto.getQuantity()) {
			model.addAttribute("products", productService.findAll());
			model.addAttribute("page", productsToSalesService.findAll(page));
			model.addAttribute("error", "Product can be delivered to production should be less than or equal "+proPur.getQuantity());
			return "cms/productToSales";
		}
		Long productQuantity=proPur.getQuantity();
		proPur.setQuantity(productQuantity-dto.getQuantity());
		productsToProductionService.save(proPur);
		productsToSalesService.save(dto);
		model.addAttribute("products", productService.findAll());
		model.addAttribute("page", productsToSalesService.findAll(page));
		model.addAttribute("success", true);
		return "cms/productToSales";
	}
	
	@RequestMapping(value="/edit",method=RequestMethod.GET)
	public String editPurchase(@RequestParam("id") Long id,Model model,Pageable page) {
		model.addAttribute("products", productService.findAll());
		model.addAttribute("model", productsToSalesService.findOne(id));
		model.addAttribute("page", productsToSalesService.findAll(page));
		return "cms/productToSales";
	}


}
