package in.cms.controller;

import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController extends AbstractController{
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String goHome(HttpServletRequest request) {
		return "redirect:/home";        
	}
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String goToHome(HttpServletRequest request) {
//		getUserSession().setAttribute("currentLocationName", getUserDetails().getLocation().fetchName());
		System.out.println("coming to redirect");
//		Iterator<GrantedAuthority> authorites = getUserDetails().getAuthorities().iterator();                
//		while (authorites.hasNext()) {
//			GrantedAuthority role = authorites.next();
//			System.out.println(role.getAuthority()+"---");
//			if(role.getAuthority().equals("ROLE_AGENCY_ADMIN") || role.getAuthority().equals("ROLE_ONBOARD_ADMIN")){
//				return "/cms/home";  
//			}
//		}
		return "home";        
	}
}
