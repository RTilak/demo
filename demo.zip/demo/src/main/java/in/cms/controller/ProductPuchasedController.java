package in.cms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import in.cms.dto.ProductPuchasedDto;
import in.cms.entity.ProductPuchased;
import in.cms.service.ProductPuchasedService;
import in.cms.service.ProductService;

@Controller
@RequestMapping(value="/purchase")
public class ProductPuchasedController {
	
	
	@Autowired
	private ProductPuchasedService productPuchasedService;
	@Autowired
	private ProductService productService;
	
//	@ModelAttribute("products")
//	public List<Products> getProducts(){
//		return productService.findAll();
//	}
	
	
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String getPurchase(Model model,Pageable page) {
		model.addAttribute("products", productService.findAll());
		model.addAttribute("model", new ProductPuchasedDto());
		model.addAttribute("page", productPuchasedService.findAll(page));
		return "cms/purchase";
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String savePurchase(@ModelAttribute("model") ProductPuchasedDto dto,Model model,Pageable page) {
		
		ProductPuchased productPuchased=productPuchasedService.findByProductId(dto.getProductId());
		if(productPuchased!=null && dto.getId() == null){
			model.addAttribute("products", productService.findAll());
			model.addAttribute("page", productPuchasedService.findAll(page));
			model.addAttribute("duplicate", true);
			return "cms/purchase";
		}
		
		productPuchasedService.save(dto);
		model.addAttribute("products", productService.findAll());
		model.addAttribute("page", productPuchasedService.findAll(page));
		model.addAttribute("success", true);
		return "cms/purchase";
	}
	
	@RequestMapping(value="/edit",method=RequestMethod.GET)
	public String editPurchase(@RequestParam("id") Long id,Model model,Pageable page) {
		model.addAttribute("products", productService.findAll());
		model.addAttribute("model", productPuchasedService.findOne(id));
		model.addAttribute("page", productPuchasedService.findAll(page));
		return "cms/purchase";
	}
}
