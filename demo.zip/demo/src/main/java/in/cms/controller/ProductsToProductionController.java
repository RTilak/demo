package in.cms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import in.cms.dto.ProductPuchasedDto;
import in.cms.dto.ProductsToProductionDto;
import in.cms.entity.ProductPuchased;
import in.cms.entity.ProductsToProduction;
import in.cms.service.ProductPuchasedService;
import in.cms.service.ProductService;
import in.cms.service.ProductsToProductionService;

@Controller
@RequestMapping(value="/production/product")
public class ProductsToProductionController {
	
	@Autowired
	private ProductsToProductionService productsToProductionService;
	@Autowired
	private ProductService productService;
	@Autowired 
	private ProductPuchasedService productPuchasedService;
	
	
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String getPurchase(Model model,Pageable page) {
		model.addAttribute("products", productService.findAll());
		model.addAttribute("model", new ProductPuchasedDto());
		model.addAttribute("page", productsToProductionService.findAll(page));
		return "cms/productToPurchase";
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String savePurchase(@ModelAttribute("model") ProductsToProductionDto dto,Model model,Pageable page) {
		
		ProductsToProduction productPuchased=productsToProductionService.findByProductId(dto.getProductId());
		if(productPuchased!=null && dto.getId() == null){
			model.addAttribute("products", productService.findAll());
			model.addAttribute("page", productsToProductionService.findAll(page));
			model.addAttribute("duplicate", true);
			return "cms/productToPurchase";
		}
		
		ProductPuchased proPur=productPuchasedService.findByProductId(dto.getProductId());
		if(proPur == null) {
			model.addAttribute("products", productService.findAll());
			model.addAttribute("page", productsToProductionService.findAll(page));
			model.addAttribute("error", "Product Should be purchased to forward it to production ");
			return "cms/productToPurchase";
		}
		if(proPur != null && proPur.getQuantity()<dto.getQuantity()) {
			model.addAttribute("products", productService.findAll());
			model.addAttribute("page", productsToProductionService.findAll(page));
			model.addAttribute("error", "Product can be delivered to production should be less than or equal "+proPur.getQuantity());
			return "cms/productToPurchase";
		}
		Long productQuantity=proPur.getQuantity();
		proPur.setQuantity(productQuantity-dto.getQuantity());
		productPuchasedService.save(proPur);
		productsToProductionService.save(dto);
		model.addAttribute("products", productService.findAll());
		model.addAttribute("page", productsToProductionService.findAll(page));
		model.addAttribute("success", true);
		return "cms/productToPurchase";
	}
	
	@RequestMapping(value="/edit",method=RequestMethod.GET)
	public String editPurchase(@RequestParam("id") Long id,Model model,Pageable page) {
		model.addAttribute("products", productService.findAll());
		model.addAttribute("model", productsToProductionService.findOne(id));
		model.addAttribute("page", productsToProductionService.findAll(page));
		return "cms/productToPurchase";
	}


}
