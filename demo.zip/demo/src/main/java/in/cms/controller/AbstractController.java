package in.cms.controller;

import javax.servlet.http.HttpSession;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import in.cms.authentication.dto.CustomUserDetails;

public class AbstractController {
	
	public static HttpSession getUserSession() {
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		return attr.getRequest().getSession(true); // true == allow create
	}
	
	public CustomUserDetails getUserDetails(){
		return CustomUserDetails.getUserDetails();
	}

}
