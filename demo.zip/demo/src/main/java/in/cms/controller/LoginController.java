package in.cms.controller;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.CredentialsExpiredException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.RememberMeServices;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import in.cms.authentication.dto.CustomUserDetails;
import in.cms.authentication.service.PasswordPolicyValidationService;
import in.cms.dto.ForcePasswordDto;
import in.cms.dto.LoginForm;
import in.cms.dto.PasswordPolicyDto;
import in.cms.entity.Employee;
import in.cms.entity.PasswordPolicy;
import in.cms.entity.User;
import in.cms.enums.PasswordPolicyViolation;
import in.cms.repository.EmployeeRepository;
import in.cms.repository.PasswordPolicyRepository;
import in.cms.repository.UserRepository;

@Controller
public class LoginController extends AbstractController {

	//    @Inject 
	//    private AuthenticationSuccessHandler successHandler;
	@Inject
	@Qualifier("authenticationManager")
	private AuthenticationManager authenticationManager;
	@Inject
	private UserRepository userRepository;
	@Inject
	private PasswordPolicyValidationService passwordPolicyValidation;
	@Inject
	@Qualifier("rememberMeService")
	private RememberMeServices rememberMeService;
//	@Inject
//	private SecurityQuestionService securityQuestionService;
//	@Inject
//	private LocationService locationService;
//	@Inject
//	private IprangeService ipService;
	@Inject
	private EmployeeRepository empRepo;
//	@Inject
//	private OrganizationRepository organizationRepository;
//	@Inject
//	private PasswordPolicyValidationService validate;
	@Inject
	private PasswordPolicyRepository passwordPolicyRepository;
	//    @Inject
	//   private ConcurrentSessionControlStrategy concurrentStrategy;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String get(ModelMap model) {
		if (getUserDetails() == null) {
			model.addAttribute("loginForm", new LoginForm());
			return "index";
		} else {
			return "redirect:/";
		}
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String post(ModelMap model, HttpServletRequest request, HttpServletResponse response, @Valid @ModelAttribute("loginForm") LoginForm loginForm, BindingResult result){
		System.out.println("camre indi");
		if (result.hasErrors()) {
			loginForm.setJ_password("");
			model.addAttribute("loginForm", loginForm);
			for(FieldError fe: result.getFieldErrors()) {
				System.out.println("--"+fe.getField()+" = "+fe.getDefaultMessage()+" = "+fe.isBindingFailure());
			}
			return "index";
		}

		Authentication token = new UsernamePasswordAuthenticationToken(loginForm.getJ_username(), loginForm.getJ_password());

		try {
			Authentication authentication = authenticationManager.authenticate(token);
			CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
			List<PasswordPolicyViolation> violations = passwordPolicyValidation.validateLogin(userDetails.getUserId().longValue());

			if (!violations.isEmpty()) {
				for (PasswordPolicyViolation violation : violations) {
					// super.logger.info(violation.toString());
					if (violation.getType().equals(PasswordPolicyViolation.Type.EXPIRY_CYCLE)) {
						throw new CredentialsExpiredException(violation.toString());
					} else {
						throw new AuthenticationException(violation.toString()) {};
					}
				}
			}

			SecurityContextHolder.getContext().setAuthentication(authentication);
			//            concurrentStrategy.onAuthentication(authentication, request, response);

			if (loginForm.getSpring_security_remember_me()) {
				rememberMeService.loginSuccess(request, response, authentication);
			}
			// super.logger.info("spring_security_remember_me = "+loginForm.getSpring_security_remember_me());

			User user = userRepository.findOne(userDetails.getUserId().longValue());
			user.setWrongLoginTries(0);
			userRepository.saveAndFlush(user);
			//            successHandler.onAuthenticationSuccess(request, response, authentication);
		} catch (CredentialsExpiredException cee) {
			// super.logger.info("login.fail = " + cee.getMessage());
			ForcePasswordDto changePassword = new ForcePasswordDto();
			changePassword.setUsername(loginForm.getJ_username());
			// userRepository.findByUsername(loginForm.getJ_username());
			Employee employee=empRepo.findOne(userRepository.findByUsername(loginForm.getJ_username()).getPerson().getId());
			PasswordPolicy policy =null;
//			Organization organization = organizationRepository.findOne(employee.getOrganization().getId());
			policy = passwordPolicyRepository.findOne(1L);
			if (policy == null) {
				policy = generateVisitorPolicy();
			}
			PasswordPolicyDto passPolicyDto = translateToCommand(policy);
			// model.addAttribute("policy",passPolicyDto);
			addSecurityQuestions(model);
			changePassword.setPasswordPolicy(passPolicyDto);
			model.addAttribute("forcePassword", changePassword);
			return "forcePassword";
		} catch (AuthenticationException ae) {
			//	super.logger.info("login.fail = " + ae.getMessage());
			if (ae.getMessage().contains("UsernameNotFoundException")) {
				model.addAttribute("fail", "Invalid Username / password");
			}else if(ae.getMessage().contains("Bad credentials")){
				model.addAttribute("fail", "Invalid Username / password");
			}else {    
//				logger.error(ae.getMessage());
				ae.printStackTrace();
				System.out.println("The error message is:"+ae.getMessage());
				model.addAttribute("fail", "Unexpected error occurred, please contact administrator");
			}
			model.addAttribute("loginForm", new LoginForm());
			return "index";
		}
		return authenticateIpAddresses(request,response);
	}

	private String authenticateIpAddresses(HttpServletRequest request, HttpServletResponse response){

		String ip = request.getHeader("X-Forwarded-For");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}        
//		List<IprangeDto> ipList= ipService.findByOrganizationId(getEmployeeOrganization());
//		boolean hasIp=false;
//		if(ipList==null || ipList.size()==0){
//			hasIp=true;
//		}
//		if(ipList.size()!=0){
//			Map<String, String> fromIp;
//			try {
//				fromIp = StringUtils.splitBaseIPAndSuffix(ip);
//
//				for(IprangeDto ipRange:ipList){    	   
//					if(fromIp.get("baseIP").equalsIgnoreCase(ipRange.getBaseIp()) && (Integer.parseInt(fromIp.get("suffixIP"))>=ipRange.getSuffixIpfrom()
//							&& Integer.parseInt(fromIp.get("suffixIP"))<=ipRange.getSuffixIpto())){
//						hasIp=true;
//						break;
//					}    	   
//				}
//			}	
//			catch (NotAnIPException e) {
//				e.printStackTrace();
//				return "redirect:/forceLogout";
//			}
//		}
//		if(!hasIp){    	   
//			SecurityContextHolder.getContext().setAuthentication(null);    	 
//			return "bgvservice/wrongIPAddress";
//		}
		return "redirect:/";
	}

	private void addSecurityQuestions(ModelMap model) {
//		List<SecurityQuestionDto> securityQuestions = securityQuestionService.findAll();
//		List<SecurityQuestionDto> firstDropDownList = securityQuestions.subList(0, 5);
//		List<SecurityQuestionDto> secondDropDownList = securityQuestions.subList(6, 10);
//		List<SecurityQuestionDto> thirdDropDownList = securityQuestions.subList(11, 15);
//		model.addAttribute("firstDropDownList", firstDropDownList);
//		model.addAttribute("secondDropDownList", secondDropDownList);
//		model.addAttribute("thirdDropDownList", thirdDropDownList);
	}

	@RequestMapping(value = "/forceLogout", method = RequestMethod.GET)
	public String forceLogout(HttpServletRequest request) {
		if(request.getSession(false) != null) {
			request.getSession(false).invalidate();
			System.out.println("--sessions invalidate--");
		}
		System.out.println("--force logout--");
		return "redirect:/";
	}

	private PasswordPolicyDto translateToCommand(PasswordPolicy policy) {
		PasswordPolicyDto passPolicyDto = new PasswordPolicyDto();

		if (policy.getPasswordStrength() == null || policy.getPasswordStrength().equals("")) {
			passPolicyDto.setLength(BigInteger.ZERO.toString());
			passPolicyDto.setUpperCaseLetterLength(BigInteger.ZERO.toString());
			passPolicyDto.setNumberLength(BigInteger.ZERO.toString());
			passPolicyDto.setSpecialChar("");
			passPolicyDto.setPasswordStrength("");
		} else {
			Map passwordStrength = passwordPolicyValidation.getValueFromPasswordStrength(policy.getPasswordStrength());
			passPolicyDto.setLength(passwordStrength.get("length").toString());
			passPolicyDto.setUpperCaseLetterLength(passwordStrength.get("upperCaseLength").toString());
			passPolicyDto.setNumberLength(passwordStrength.get("digitLength").toString());
			passPolicyDto.setSpecialChar(passwordStrength.get("specialChar").toString());
			passPolicyDto.setPasswordStrength(policy.getPasswordStrength());
		}
		passPolicyDto.setNumberOfChanges(policy.getNumberOfChanges() == null ? BigInteger.ZERO.toString() : policy.getNumberOfChanges().toString());
		passPolicyDto.setNumberOfHistories(policy.getHistory() == null ? BigInteger.ZERO.toString() : policy.getHistory().toString());
		if (policy.getExpiryCycle() == null) {
			passPolicyDto.setNoOfDay(BigInteger.ZERO.toString());
			passPolicyDto.setNoOfMonth(BigInteger.ZERO.toString());
			passPolicyDto.setNoOfWeek(BigInteger.ZERO.toString());
			passPolicyDto.setNumberOfChanges(BigInteger.ZERO.toString());
		} else {
			passPolicyDto.setExpiryCycle(policy.getExpiryCycle().toString());
			passPolicyDto.setNoOfDay(policy.getDays().toString());
			passPolicyDto.setNoOfWeek(policy.getWeeks().toString());
			passPolicyDto.setNoOfMonth(policy.getMonths().toString());
		}
		passPolicyDto.setNumberOfTries(policy.getNumberOfTries() == null ? BigInteger.ZERO.toString() : policy.getNumberOfTries().toString());
		return passPolicyDto;
	}
	private PasswordPolicy generateVisitorPolicy() {
		PasswordPolicy pp = new PasswordPolicy();

		pp.setPasswordStrength("20P1U1N9S643536373833424041");
		pp.setDays(0);
		pp.setWeeks(0);
		pp.setMonths(3);
		pp.setHistory(3);
		pp.setExpiryCycle(5);
		pp.setNumberOfChanges(0);
		pp.setNumberOfTries(5);
		pp.setActive(Boolean.TRUE);

		return pp;
	}
}
