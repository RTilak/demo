package in.cms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import in.cms.entity.Products;
import in.cms.service.ProductService;

@Controller
@RequestMapping(value="/product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String getProducts(Model model,Pageable page) {
		model.addAttribute("product", new Products());
		model.addAttribute("page", productService.findAll(page));
		return "cms/product";
	}
	
	@RequestMapping(value="/edit",method=RequestMethod.GET)
	public String editProducts(@RequestParam(value="id") Long id,Model model,Pageable page) {
		model.addAttribute("product", productService.findOne(id));
		model.addAttribute("page", productService.findAll(page));
		return "cms/product";
	}
	
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String saveProducts(@ModelAttribute("product") Products product,Model model,Pageable page) {
		productService.save(product);
		model.addAttribute("page", productService.findAll(page));
		model.addAttribute("success", true);
		return "cms/product";
	}
}
