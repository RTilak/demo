package in.cms.enums;


public enum PersonType  implements BaseEnum{
	
	EMPLOYEE("EMPLOYEE", "Employee"), 
	AGENCY("AGENCY", "AGENCY");
	
	private String code;
	private String description;
	
	private PersonType(String code, String description) {
		this.code = code;
		this.description = description;
	}
	
	public String getCode() {
		return this.code;
	}
	
	public String getDescription() {
		return this.description;
	}

}
