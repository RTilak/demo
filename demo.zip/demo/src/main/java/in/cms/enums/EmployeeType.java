package in.cms.enums;


public enum EmployeeType  implements BaseEnum {

	SUPER_ADMIN("SUPER_ADMIN", "Super Admin"),
	COMPANY_ADMIN("COMPANY_ADMIN", "Customer Admin"),
    LOCATION_ADMIN("LOCATION_ADMIN", "SBU Admin"),
	AGENCY_ADMIN("AGENCY_ADMIN", "Company Admin"),
	SUPERVISOR_ADMIN("SUPERVISOR_ADMIN","Supervisor Admin"),
	COMPLIANCE_TEAM("COMPLIANCE_TEAM","Compliance Team"),
	PAYROLL_TEAM("PAYROLL_TEAM","Payroll Team"),
	CREDIT_CONTROL_TEAM("CREDIT_CONTROL_TEAM","Credit Control Team"),
	SCM_TEAM("SCM_TEAM","SCM Team"),
	O2C_TEAM("O2C_TEAM","O2C Team"),
	ARM("ARM","ARM User")	
	;
	private String code;
    private String description;

    private EmployeeType(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return this.code;
    }
    

    public String getDescription() {
        return this.description;
    }
    
    public static EmployeeType getEmployeeType(String value){
   	 if (value != null) {
   		 for (EmployeeType b : EmployeeType.values()) {
   		        if (value.equalsIgnoreCase(b.code)) {
   		          return b;
   		        }
   		 }
   	 }
   	 return null;
   }
}

