package in.cms.enums;

public enum Role implements BaseEnum {
 
	
    ROLE_SUPERADMIN("ROLE_SUPERADMIN", "Super Admin"),
    ROLE_AGENCY_ADMIN("ROLE_AGENCY_ADMIN", "Company Admin"),
    ROLE_SUPERVISOR_ADMIN("ROLE_SUPERVISOR_ADMIN","Supervisor Admin"), 
    
	ROLE_HOME("ROLE_HOME","Home Page"),
	ROLE_CHANGE_PASSWORD("ROLE_CHANGE_PASSWORD", "Change Password"),
	ROLE_COMPANY_USER("ROLE_COMPANY_USER", "User Creation"),
	ROLE_CUSTOMER_USER("ROLE_CUSTOMER_USER", "Customer User Creation"),
	ROLE_CUSTOMER_USER_LIST("ROLE_CUSTOMER_USER_LIST", "Customer User List"),
	ROLE_COMPANY_USER_UPLOAD("ROLE_COMPANY_USER_UPLOAD", "User Upload"),
	ROLE_COMPANY_USER_LIST("ROLE_COMPANY_USER_LIST", "User List"),
	ROLE_PASSWORD_POLICY("ROLE_PASSWORD_POLICY", "Password Policy"),
	ROLE_COMPANY_PASSWORD_POLICY("ROLE_COMPANY_PASSWORD_POLICY", "Company Password Policy");
    
    private String code;
    
    private String description;

    private Role(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return this.code;
    }

    public String getDescription() {
        return this.description;
    }
}
