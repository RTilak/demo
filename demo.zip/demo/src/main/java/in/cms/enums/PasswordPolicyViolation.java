package in.cms.enums;

import java.text.MessageFormat;

import in.cms.entity.PasswordPolicy;

public class PasswordPolicyViolation {

    private String message = "";

    public enum Type {

        FAILED_LOGIN_TRIES("User ID is locked. Please contact the administrator"),
        EXPIRY_CYCLE("Your password has expired. Please contact the administrator"),
        STRENGTH("Password strength should be ({0})"),
        HISTORY_REUSE("Please choose a password that is different from your last ({0}) passwords."),
        MAX_CHANGES("Password can be changed to a maximum of {0} times in a day."),
        CUSTOM("{0}");
        private String description;

        private Type(String description) {
            this.description = description;
        }

        public String getDescription() {
            return this.description;
        }
    }
    private Type type;
    private PasswordPolicy policy;

    public PasswordPolicyViolation(Type type, PasswordPolicy policy) {
        this.type = type;
        this.policy = policy;
    }

    public PasswordPolicyViolation(Type type, String message) {
        this.type = type;
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        MessageFormat formatter = new MessageFormat(type.getDescription());
        Object[] params = new Object[1];

        switch (type) {
            case FAILED_LOGIN_TRIES:
                params[0] = policy.getNumberOfTries();
                break;
            case EXPIRY_CYCLE:
                params[0] = policy.getExpiryCycle();
                break;
            case STRENGTH:
                params[0] = policy.getPasswordStrength();
                break;
            case HISTORY_REUSE:
                params[0] = policy.getHistory();
                break;
            case MAX_CHANGES:
                params[0] = policy.getNumberOfChanges();
                break;
            case CUSTOM:
                params[0] = message;
                break;
        }

        StringBuffer descriptionText = new StringBuffer();
        formatter.format(params, descriptionText, null);
        return descriptionText.toString();
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public PasswordPolicy getPolicy() {
        return policy;
    }

    public void setPolicy(PasswordPolicy policy) {
        this.policy = policy;
    }
}

