package in.cms.enums;


public interface BaseEnum {
	
	String getCode();
	
	String getDescription();
}
