/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
function relationshipTypeValidation(id){
    var str=/^(?=.*?[a-zA-Z])[0-9a-zA-Z&-_\s]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter Valid Relationship Type");
        return false; 
    }
}
function purposeValidation(id){
    var str=/^(?=.*?[a-zA-Z])[0-9a-zA-Z#./&-_\s]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter Valid Purpose");
        return false; 
    }
}
function designationValidation(id){
    var str=/^(?=.*?[a-zA-Z])[0-9a-zA-Z./&-_\s]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter Valid Designation");
        return false; 
    }
}

function identificationProfileValidation(id){
    var str=/^(?=.*?[a-zA-Z])[0-9a-zA-Z#./&-_\s]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter Valid IdentificationProfile");
        return false; 
    }
}
function locationValidation(id){
    var str=/^(?=.*?[a-zA-Z])[0-9a-zA-Z#./&-_\s]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter Valid Location");
        return false; 
    }
}

function departmentValidation(id){
    var str = /^(?=.*?[a-zA-Z])[0-9a-zA-Z.,+-_ #/&]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter Valid Department");
        return false; 
    }
}
function departmentDescriptionValidation(id){
    var str = /^(?=.*?[a-zA-Z])[0-9a-zA-Z.,+-_ #/&]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter Valid Description");
        return false; 
    }
}

function organisationValidation(id){
    var str=/^(?=.*?[a-zA-Z])[0-9a-zA-Z#/&-_\s]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter Valid Organisation");
        return false; 
    }
}

function ppeValidation(id){
    var str = /^(?=.*?[a-zA-Z])[0-9a-zA-Z.,+-_ #/&]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter valid PPE Name");
        return false; 
    }
}
function specialCharacterValidation(id){
    var exr=/^[@#$%&!*(),]+$/
    if(exr.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html(" special Character should be (@, #, $, %, &, !, *, ())");
        return false; 
    }
}

function futureDate(id){
    var date=new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate());
    if(getDate(id)< date){
        $("#"+id).addClass('borderRed');
        $("#"+id).val("");
        $("#"+id+'Error').html("Date Must be current or future Date");
        return false;
    }else{
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }
}
function backDate(id){
    var date=new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate());
    if(getDate(id)> date){
        $("#"+id).addClass('borderRed');
        $("#"+id).val("");
        $("#"+id+'Error').html("Date Must be lesser than current Date");
        return false;
    }else{
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }
}
function ageValidation(id){
    var age = 18;
    var date=$("#"+id).val();
   
    //    var mydate = new Date(id);
//    mydate.setFullYear(getDate(id).getFullYear());
    var currdate=new Date();
    currdate.setFullYear(currdate.getFullYear());
    var adultdate=new Date();
    adultdate.setFullYear(adultdate.getFullYear() - age);
    if(date==null || date==""){
        $("#"+id).addClass('borderRed');
        $("#"+id).val("");
        $("#"+id+'Error').html("Date Must be lesser than current Date");
        return false;
    }else if(getDate(id)> currdate){
        $("#"+id).addClass('borderRed');
        $("#"+id).val("");
        $("#"+id+'Error').html("Date Must be lesser than current Date");
        return false;
    }else if ((adultdate - getDate(id)) < 0){
        $("#"+id).addClass('borderRed');
        $("#"+id).val("");
        $("#"+id+'Error').html("Age is below 18");
        return false;
    }else{
        $('#'+id).removeClass('borderRed')
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }
}

function dateMatcher(id){
    var reg=/^(0?[1-9]|[12][0-9]|3[01])[-](0?[1-9]|1[012])[-]((19|20)\d\d)$/;
    var date=$('#'+id).val();
    if(date.match(reg)!=null){
        $('#'+id).removeClass('borderRed');
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter correct Date");
        return false;
    }
}
function nullValidation(id){
    if($("#"+id).val()==null || $('#'+id).val()=="" || (/^\s*$/).test($('#'+id).val()) ){
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').show();
        $('#'+id+'Error').addClass("fieldError");
        $('#'+id+'Error').html("<font color=red bold=true>*Mandatory Field!</font>");
        return false;
    }else{
        $('#'+id).removeClass('borderRed');
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        $('#'+id+'Error').removeClass("fieldError");
        $('#'+id+'Error').hide();
        return true;
    }
}

function getDate(id){
    var date=$("#"+id).val();
    var day=date.split("-")[0];
    var month=date.split("-")[1];
    var year=date.split("-")[2];
    return new Date(year,(month-1),day);
}

function validateonchange(id){          //mandatory
   
    if($('#'+id).val()=="" || (/^\s*$/).test($('#'+id).val()) || $('#'+id).val()=="-1" || $('#'+id).val()==null){
    	$('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').show();
        $('#'+id+'Error').addClass("fieldError");
        $('#'+id+'Error').html("<font color=red bold=true>*Mandatory Field!</font>");
        return false;
    }else{
    	 $('#'+id).removeClass('borderRed');
         $('#'+id+'Error').html("");
         $('#'+id).addClass('borderGray');
         $('#'+id+'Error').removeClass("fieldError");
         $('#'+id+'Error').hide();
        return true;
    }
}
function onlyNumber(id,NumLength){
  var reg=/^\d+$/;
  if(reg.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed');
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter only Number");
        return false; 
    }
}
    
    
    
function onlyNumberAndLetters(id){
    var str = /^[0-9a-zA-Z&]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed');
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter only Alphabet/Number or both");
        return false; 
    }
}
function onlyLetters(id){
    var str = /^[a-zA-Z]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed');
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter only Alphabet");
        return false; 
    }
}
function onlyNumberAndLettersWithSpace(id){
    var str = /^[0-9a-zA-Z][0-9a-zA-Z\s]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed');
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter Alphabets/Numbers or both");
        return false; 
    }
}
function onlyNumberAndLettersWithSpaceAndUnderscore(id){
    var str = /^[0-9a-zA-Z\s]+$/;
    if(str.test($("#"+id).val())){
        $('#'+id).removeClass('borderRed');
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;
    }else{
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter only Alphanumeric");
        return false; 
    }
}

function fileNameMandatory(id){
	var val = document.getElementById(id).value;
	if(val == null || val == "" || (/^\s*$/).test(val)){
		document.getElementById(id).value="";
		document.getElementById(id+'Error').setAttribute('style', '');
		document.getElementById(id+'Error').setAttribute('class', 'fieldError');
		document.getElementById(id+'Error').innerHTML = '<font color=red bold=true>*Mandatory Field!</font>';
		return false;			
	}
} 

function fileTypeValidation(id,fileTypes){
	var val = document.getElementById(id).value;
	var extension = val.replace(/^.*\./, '');
	//alert("Its inside1 : "+val);
	if(extension == val){
		//alert("Its inside2 : "+ extension);
		return true;
	}else{	
		//alert("Its inside3");
		var error = true;
		$.each(fileTypes,function(i,fileType){
			if(extension == fileType){
				error = false;
			}
		});
		if(error){
			document.getElementById(id).value="";
			document.getElementById(id+'Error').setAttribute('style', '');
			document.getElementById(id+'Error').setAttribute('class', 'fieldError');
			document.getElementById(id+'Error').innerHTML = '<font color=red bold=true>Please upload only '+ fileTypes +' files</font>';
			return false;			
		}else{
			document.getElementById(id+'Error').setAttribute('class', '');
			document.getElementById(id+'Error').setAttribute('style', 'display:none');
			return true;
		}
	}
}

function validatePhone(id) {  
    //var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/; 
  //  alert("Hello");
    var phoneno=/^\+?[0-9]{10}$/;
    if((phoneno.test($('#'+id).val()))){  
        $('#'+id).removeClass('borderRed');
        $('#'+id+'Error').html("");
        $('#'+id).addClass('borderGray');
        return true;  
    }  
    else  
    {  
         $('#'+id).removeClass('borderGray');
        $('#'+id).addClass('borderRed');
        $('#'+id).val("");
        $('#'+id+'Error').html("Please enter a valid Mobile number");
        return false;  
    }  
}