function fillListForRequest(url,targetId,sourceId,selectedId){
	if($('#'+sourceId).val()!="-1" && $('#'+sourceId).val()!="" && !$('#'+sourceId).val().match(/^\s*$/)){
        $('#'+targetId).text("");
        $.ajax({
            type: "POST",
            url: url,
            success: function(data) {
              	var content="<option value='-1'>Select</option>";
            	$.each(data,function(i,value){
                    var res=value.split(',');
                    if(selectedId == res[0]){
                        content += "<option value='"+res[0]+"' selected>"+res[1]+"</option>";
                    }else
                    {
                        content += "<option value='"+res[0]+"'>"+res[1]+"</option>";
                    }
                });
                $('#'+targetId).append(content);
            },
            error:function(){
            	alert(error);
            }
        });
    }
}


function isCandidateAccepted(url, targetId) {
	$.ajax({
		type : "POST",
		url : url,
		success : function(data) {
			//alert(data);
			if (data == "true") {
				$('#'+targetId).hide();
			}else{
				$('#'+targetId).show();
			}
		},
		error : function() {
			alert(error);
		}
	});
}