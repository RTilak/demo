function cityStateSuggestion(cityId,stateId,countryId){
	$('#cityId').typeahead({
		source:function(query, process){
			var _self = this;
			_self.rawData = {};
			_self.formatedData = [];
			return $.getJSON('${pageContext.servletContext.contextPath}/citystate/cities/'+$('#cityId').val(),
					function (data) {
				$.each(data,function(i,item){
					var city = item.city;
					var state = item.state;
					var country = item.country; 
					_self.rawData[item.id] = item;
					_self.formatedData.push(city+
							' <span style="display:none">id.'+item.id+'</span>'+
							'<span style="font-size: 10px; line-height:4px; padding:0px; margin:0px;">'+
							city+'-'+state+ '</span>');
				});
				return process(_self.formatedData); 
			});
		},
		minLength: 3,
		updater:function(item){
			var returnName;
			//this.$element.attr("readonly", true);
			var id = item.match("id\\.(\\d+)");                        
			var obj = this.rawData[id[1]];
			returnName = obj.city;
			$('#cityId').val(returnName);
			$('#stateId').val(obj.state);
			$('#countryId').val(obj.country);
			return returnName;
		} 
	});
} 