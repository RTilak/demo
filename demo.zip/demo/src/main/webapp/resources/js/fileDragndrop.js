//checks whether the browser is advanced and dragndrop is enabled
var isAdvancedUpload = function() {
	var div = document.createElement('div');
	return (('draggable' in div) || ('ondragstart' in div && 'ondrop' in div)) && 'FormData' in window && 'FileReader' in window;
}();

// dragndrop element
var droppedFiles = false;

// enables darndrop css for advance browsers where dragndrop is enabled
if (isAdvancedUpload) {
	$('.box').addClass('has-advanced-upload');

	$('.box').on('drag dragstart dragend dragover dragenter dragleave drop', function(e) {
		e.preventDefault();
		e.stopPropagation();
	})
	.on('dragover dragenter', function() {
		$(this).addClass('is-dragover');
		$(this).parent('td').addClass('is-dragover');
	})
	.on('dragleave dragend drop', function() {
		$(this).parent('td').removeClass('is-dragover');
		$(this).removeClass('is-dragover');
	})
	.on('drop', function(e) {
		droppedFiles = e.originalEvent.dataTransfer.files;
		$(this).trigger('submit');
	});
	// for multiple files with manual submit
	/* .on('drop', function(e) {   
		  droppedFiles = e.originalEvent.dataTransfer.files;
		}); */

}
$('.box__file').on('change', function(e) {
	$(this.form).trigger('submit');
});

//call for onsubmit
$('.box').on('submit', function(e) {
	var form = $(this);
	var index = form.attr('id');
	if (form.hasClass('is-uploading')) return false;
	form.addClass('is-uploading').removeClass('is-error');
	if (isAdvancedUpload) {
		// ajax for modern browsers
		//ajax for advanced browsers which support file uploading via XMLHttpRequest.
		e.preventDefault();
		var ajaxData = new FormData(form.get(0));
		if (droppedFiles) {
			$.each( droppedFiles, function(i, file) {
				ajaxData.append($('#file'+index).attr('name'), file );
			});
		}
		ajaxData.append($('#identifier'+index).attr('name'), $('#identifier'+index).attr('value'));
		$.ajax({
			url: form.attr('action'),
			type: form.attr('method'),
			data: ajaxData,
			// dataType: 'json',
			cache: false,
			contentType: false,
			processData: false,
			complete: function() {
				form.removeClass('is-uploading');
			},
			success: function(data) {
				form.addClass('is-success');
				$('#div'+index).show();
				/* form.addClass(data.success == true ? 'is-success' : 'is-error' );
				      	if (!data.success) $errorMsg.text(data.error); */
			},
			error: function() {
				form.addClass('is-error');
				// Log the error, show an alert, whatever works for you
			}
		});
	} else {
		alert("legacy");
		// ajax for legacy browsers
		var iframeName  = 'uploadiframe' + new Date().getTime();
		$iframe   = $('<iframe name="' + iframeName + '" style="display: none;"></iframe>');
		$('body').append($iframe);
		form.attr('target', iframeName);
		$iframe.one('load', function() {
			var data = JSON.parse($iframe.contents().find('body' ).text());
			form
			.removeClass('is-uploading')
			.addClass(data.success == true ? 'is-success' : 'is-error')
			.removeAttr('target');
			if (!data.success) $errorMsg.text(data.error);
			form.removeAttr('target');
			$iframe.remove();
		});
	}	
});

(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);